import { motion } from "framer-motion";
import type { ReactNode } from "react";
import { EASE, RM } from "../lib/motion";

export default function PageTransition({ children }: { children: ReactNode }) {
  if (RM) return <>{children}</>;
  return (
    <motion.div
      initial={{ opacity: 0, y: 12 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, y: -8 }}
      transition={{ duration: 0.45, ease: EASE }}
    >
      {children}
    </motion.div>
  );
}
