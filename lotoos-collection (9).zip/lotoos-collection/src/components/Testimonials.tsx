import { motion } from "framer-motion";
import { Quote } from "lucide-react";
import { useTestimonials } from "../hooks/useTestimonials";
import Reveal from "./Reveal";
import { EASE, RM, viewportOnce } from "../lib/motion";

export default function Testimonials() {
  const { items } = useTestimonials();
  if (!items.length) return null;

  return (
    <section className="py-24 md:py-32 bg-noir-900 relative">
      <div className="absolute top-0 inset-x-0 hairline" />
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <Reveal className="text-center mb-16">
          <div className="flex items-center justify-center gap-4 mb-4">
            <span className="h-px w-10 bg-gold-500/60" />
            <span className="font-latin tracking-[.4em] text-[11px] text-gold-500 uppercase">
              Clients
            </span>
            <span className="h-px w-10 bg-gold-500/60" />
          </div>
          <h2 className="section-title">تجربه مشتریان</h2>
        </Reveal>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-5">
          {items.map((t, i) => (
            <motion.div
              key={t.id}
              initial={RM ? false : { opacity: 0, y: 32 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={viewportOnce}
              transition={{ delay: RM ? 0 : i * 0.12, duration: 0.75, ease: EASE }}
              whileHover={RM ? undefined : { y: -4 }}
              className="card-luxury p-8 md:p-9 bg-noir-950 border border-gold-500/12"
            >
              <Quote className="text-gold-500/30 mb-5" size={26} strokeWidth={1.5} />
              <p className="text-ivory/75 text-sm leading-8 mb-8 font-light">{t.text}</p>
              <div className="pt-5 border-t border-ivory/8">
                <p className="text-ivory text-sm font-medium">{t.name}</p>
                <p className="text-gold-500/60 text-xs mt-1 tracking-wide">{t.role}</p>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
