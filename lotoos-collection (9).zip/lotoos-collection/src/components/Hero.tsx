import { motion, useScroll, useTransform } from "framer-motion";
import { Link } from "react-router-dom";
import { useRef } from "react";
import { useSiteSettings } from "../hooks/useSiteSettings";
import { MaskLine } from "./Reveal";
import { EASE, RM } from "../lib/motion";

export default function Hero() {
  const { settings } = useSiteSettings();
  const ref = useRef<HTMLElement>(null);
  const { scrollYProgress } = useScroll({
    target: ref,
    offset: ["start start", "end start"],
  });
  const fade = useTransform(scrollYProgress, [0, 0.55], [1, 0]);
  const rise = useTransform(scrollYProgress, [0, 0.55], [0, 80]);

  return (
    <section ref={ref} className="relative h-screen min-h-[680px] w-full overflow-hidden noise">
      <div className="absolute inset-0">
        <motion.img
          src={settings.heroImage}
          alt={settings.brandName}
          className="w-full h-full object-cover object-center kb"
          initial={RM ? false : { scale: 1.12 }}
          animate={{ scale: 1 }}
          transition={{ duration: 2.4, ease: EASE }}
        />
        <div className="absolute inset-0 bg-gradient-to-t from-noir-950 via-noir-950/55 to-noir-950/25" />
        <div className="absolute inset-0 bg-gradient-to-l from-noir-950/50 via-transparent to-transparent" />
      </div>

      <motion.div
        style={RM ? undefined : { opacity: fade, y: rise }}
        className="relative z-10 h-full max-w-7xl mx-auto px-6 md:px-10 flex flex-col justify-center"
      >
        <motion.div
          initial={RM ? false : { opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ duration: 0.6 }}
          className="max-w-2xl"
        >
          <div className="flex items-center gap-4 mb-6 overflow-hidden">
            <motion.span
              className="h-px bg-gold-500/70 block"
              initial={RM ? false : { width: 0 }}
              animate={{ width: 48 }}
              transition={{ duration: 1, delay: 0.2, ease: EASE }}
            />
            <motion.span
              className="font-latin tracking-[.4em] text-[11px] uppercase text-gold-500"
              initial={RM ? false : { opacity: 0, x: -12 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.8, delay: 0.35, ease: EASE }}
            >
              Lotoos Atelier
            </motion.span>
          </div>

          <h1 className="font-display text-5xl sm:text-6xl md:text-7xl lg:text-8xl leading-[1.1] text-ivory">
            <MaskLine delay={0.25}>آغازی برای خلق</MaskLine>
            <MaskLine delay={0.42}>
              استایلی <span className="text-gold-400">منحصر به فرد</span>
            </MaskLine>
          </h1>

          <motion.p
            initial={RM ? false : { opacity: 0, y: 18 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.9, delay: 0.7, ease: EASE }}
            className="mt-7 max-w-xl text-ivory/65 leading-8 text-sm md:text-base font-light"
          >
            {settings.tagline}
            <span className="block mt-2 text-ivory/50">
              طراحی و دوخت سفارشی لباس مجلسی، عروس و عقد؛ با پارچه‌های ممتاز و ظرافت‌های دست‌دوز.
            </span>
          </motion.p>

          <motion.div
            initial={RM ? false : { opacity: 0, y: 18 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.9, delay: 0.9, ease: EASE }}
            className="mt-10 flex flex-col sm:flex-row gap-4"
          >
            <Link to="/collections" className="btn-primary">
              مشاهده کالکشن
              <span className="text-base leading-none">←</span>
            </Link>
            <Link to="/custom-order" className="btn-outline">
              سفارش طراحی اختصاصی
            </Link>
          </motion.div>
        </motion.div>
      </motion.div>

      <div className="absolute bottom-0 inset-x-0 z-10 flex items-end justify-between px-6 md:px-10 pb-7">
        <motion.span
          initial={RM ? false : { opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 1.2, duration: 0.8 }}
          className="font-latin tracking-[.35em] text-[10px] text-ivory/40 uppercase hidden sm:block"
          dir="ltr"
        >
          Est. 1392 — Tehran
        </motion.span>
        <div className="mx-auto flex flex-col items-center gap-2 text-ivory/50">
          <span className="text-[10px] tracking-[.3em]">اسکرول</span>
          {!RM && (
            <motion.span
              className="w-px h-12 bg-gradient-to-b from-gold-500 to-transparent block"
              animate={{ scaleY: [0.2, 1, 0.2], opacity: [0.4, 1, 0.4] }}
              transition={{ duration: 2.2, repeat: Infinity, ease: "easeInOut" }}
              style={{ transformOrigin: "top" }}
            />
          )}
        </div>
        <motion.span
          initial={RM ? false : { opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 1.3, duration: 0.8 }}
          className="font-nastaliq text-gold-500/80 text-sm hidden sm:block"
        >
          دوختِ دست، امضای ماست
        </motion.span>
      </div>
    </section>
  );
}
