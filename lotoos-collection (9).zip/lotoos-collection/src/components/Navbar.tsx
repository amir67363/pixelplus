import { useState, useEffect, useMemo } from "react";
import { Link, useLocation, useNavigate } from "react-router-dom";
import { motion, AnimatePresence } from "framer-motion";
import { Menu, X, Heart, Search } from "lucide-react";
import Lotus from "./Lotus";
import { EASE, RM } from "../lib/motion";
import { useFavorites } from "../hooks/useFavorites";
import { useProducts } from "../hooks/useProducts";

const links = [
  { to: "/", label: "خانه" },
  { to: "/collections", label: "کالکشن‌ها" },
  { to: "/gallery", label: "گالری" },
  { to: "/about", label: "داستان ما" },
  { to: "/custom-order", label: "سفارش اختصاصی" },
  { to: "/appointment", label: "رزرو مشاوره" },
  { to: "/track", label: "پیگیری" },
  { to: "/contact", label: "تماس" },
];

export default function Navbar() {
  const [open, setOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);
  const [searchOpen, setSearchOpen] = useState(false);
  const [q, setQ] = useState("");
  const location = useLocation();
  const navigate = useNavigate();
  const { count } = useFavorites();
  const { products } = useProducts();

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 24);
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  useEffect(() => {
    setOpen(false);
    setSearchOpen(false);
    setQ("");
  }, [location.pathname]);

  const results = useMemo(() => {
    const s = q.trim();
    if (s.length < 2) return [];
    return products
      .filter(
        (p) =>
          p.name.includes(s) ||
          p.description.includes(s) ||
          p.fabric.includes(s)
      )
      .slice(0, 6);
  }, [q, products]);

  return (
    <header
      className={`fixed top-0 inset-x-0 z-50 transition-all duration-500 ${
        scrolled ? "glass py-3" : "bg-transparent py-5"
      }`}
    >
      <div className="max-w-7xl mx-auto px-5 md:px-10 flex items-center justify-between gap-4">
        <Link to="/" className="flex items-center gap-3 group shrink-0">
          <Lotus size={34} className="text-gold-500 group-hover:text-gold-300 transition-colors" />
          <div className="leading-none hidden sm:block">
            <p className="font-latin tracking-[0.32em] text-sm text-ivory" dir="ltr">
              LOTOOS
            </p>
            <p className="text-[9px] tracking-[0.28em] text-gold-500/70 uppercase mt-1">
              Collection
            </p>
          </div>
        </Link>

        <nav className="hidden xl:flex items-center gap-0.5">
          {links.map((l) => {
            const active = location.pathname === l.to;
            return (
              <Link
                key={l.to}
                to={l.to}
                className={`px-3 py-2 text-[13px] transition-colors duration-300 ${
                  active ? "text-gold-400" : "text-ivory/55 hover:text-ivory"
                }`}
              >
                {l.label}
              </Link>
            );
          })}
        </nav>

        <div className="flex items-center gap-1 sm:gap-2">
          <button
            type="button"
            onClick={() => setSearchOpen((v) => !v)}
            className="p-2.5 text-ivory/70 hover:text-gold-400 transition-colors"
            aria-label="جستجو"
          >
            <Search size={18} />
          </button>
          <Link
            to="/favorites"
            className="relative p-2.5 text-ivory/70 hover:text-gold-400 transition-colors"
            aria-label="علاقه‌مندی‌ها"
          >
            <Heart size={18} />
            {count > 0 && (
              <span className="absolute top-1 left-1 w-4 h-4 bg-gold-500 text-noir-950 text-[9px] font-bold flex items-center justify-center rounded-full">
                {count > 9 ? "۹+" : count}
              </span>
            )}
          </Link>
          <Link
            to="/custom-order"
            className="hidden lg:inline-flex items-center border border-gold-500/50 text-gold-400 text-xs px-4 py-2 hover:bg-gold-500 hover:text-noir-950 transition-all duration-400"
          >
            طراحی اختصاصی
          </Link>
          <button
            onClick={() => setOpen(!open)}
            className="xl:hidden p-2 text-ivory/80 hover:text-gold-400"
            aria-label="منو"
          >
            {open ? <X size={22} /> : <Menu size={22} />}
          </button>
        </div>
      </div>

      {/* Search panel */}
      <AnimatePresence>
        {searchOpen && (
          <motion.div
            initial={{ opacity: 0, y: -8 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -8 }}
            transition={{ duration: 0.3, ease: EASE }}
            className="absolute inset-x-0 top-full border-b border-gold-500/15 bg-noir-950/95 backdrop-blur-xl"
          >
            <div className="max-w-2xl mx-auto px-5 py-5">
              <input
                autoFocus
                value={q}
                onChange={(e) => setQ(e.target.value)}
                placeholder="جستجوی لباس، پارچه، مدل..."
                className="input-luxury text-sm"
              />
              {results.length > 0 && (
                <ul className="mt-3 border border-gold-500/10 divide-y divide-ivory/5">
                  {results.map((p) => (
                    <li key={p.id}>
                      <button
                        type="button"
                        className="w-full text-right px-4 py-3 text-sm text-ivory/80 hover:bg-gold-500/10 hover:text-gold-300 transition-colors flex items-center gap-3"
                        onClick={() => {
                          navigate(`/product/${p.id}`);
                          setSearchOpen(false);
                        }}
                      >
                        <img src={p.images[0]} alt="" className="w-10 h-12 object-cover" />
                        <span>{p.name}</span>
                      </button>
                    </li>
                  ))}
                </ul>
              )}
              {q.trim().length >= 2 && results.length === 0 && (
                <p className="text-ivory/35 text-sm mt-3 text-center">نتیجه‌ای یافت نشد</p>
              )}
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      <AnimatePresence>
        {open && (
          <motion.div
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: "auto" }}
            exit={{ opacity: 0, height: 0 }}
            className="xl:hidden glass-strong overflow-hidden border-t border-gold-500/10"
          >
            <div className="px-6 py-6 flex flex-col gap-1">
              {links.map((l, i) => (
                <motion.div
                  key={l.to}
                  initial={RM ? false : { opacity: 0, x: 16 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: RM ? 0 : 0.05 + i * 0.04, duration: 0.45, ease: EASE }}
                >
                  <Link
                    to={l.to}
                    className={`block py-3 text-base ${
                      location.pathname === l.to ? "text-gold-400" : "text-ivory/70"
                    }`}
                  >
                    {l.label}
                  </Link>
                </motion.div>
              ))}
              <Link to="/custom-order" className="btn-primary mt-4 text-center text-xs">
                ثبت سفارش اختصاصی
              </Link>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </header>
  );
}
