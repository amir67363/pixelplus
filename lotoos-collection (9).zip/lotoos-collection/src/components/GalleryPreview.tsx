import { motion } from "framer-motion";
import { Link } from "react-router-dom";
import { useGallery } from "../hooks/useGallery";
import Reveal from "./Reveal";
import { EASE, RM, viewportOnce } from "../lib/motion";

export default function GalleryPreview() {
  const { gallery } = useGallery();
  const items = gallery.slice(0, 8);

  return (
    <section className="py-24 md:py-32 bg-noir-950">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <Reveal className="text-center mb-14">
          <div className="flex items-center justify-center gap-4 mb-4">
            <span className="h-px w-10 bg-gold-500/60" />
            <span className="font-latin tracking-[.4em] text-[11px] text-gold-500 uppercase">
              Atelier
            </span>
            <span className="h-px w-10 bg-gold-500/60" />
          </div>
          <h2 className="section-title">گالری و لحظه‌ها</h2>
          <p className="text-ivory/40 text-sm mt-5 max-w-md mx-auto leading-8 font-light">
            نگاهی به جزئیات دوخت، بافت پارچه و لحظه‌هایی که لباس جان می‌گیرد.
          </p>
        </Reveal>

        <div className="grid grid-cols-2 md:grid-cols-4 gap-2.5 md:gap-3">
          {items.map((item, i) => (
            <motion.div
              key={item.id}
              initial={RM ? false : { opacity: 0, scale: 0.94 }}
              whileInView={{ opacity: 1, scale: 1 }}
              viewport={viewportOnce}
              transition={{ delay: RM ? 0 : i * 0.05, duration: 0.65, ease: EASE }}
              className={`relative overflow-hidden group ${
                i === 0 || i === 5
                  ? "md:col-span-2 md:row-span-2 aspect-square md:aspect-auto md:min-h-[280px]"
                  : "aspect-square"
              }`}
            >
              <motion.img
                src={item.src}
                alt={item.alt}
                className="w-full h-full object-cover"
                loading="lazy"
                whileHover={RM ? undefined : { scale: 1.1 }}
                transition={{ duration: 1, ease: EASE }}
              />
              <div className="absolute inset-0 bg-black/0 group-hover:bg-black/45 transition-colors duration-500 flex items-center justify-center">
                <span className="text-ivory text-[11px] tracking-[0.25em] opacity-0 group-hover:opacity-100 transition-opacity duration-500 uppercase">
                  {item.alt}
                </span>
              </div>
            </motion.div>
          ))}
        </div>

        <Reveal delay={0.15} className="text-center mt-12">
          <Link to="/gallery" className="btn-outline">
            مشاهده گالری کامل
          </Link>
        </Reveal>
      </div>
    </section>
  );
}
