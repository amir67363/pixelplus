export default function Lotus({
  size = 30,
  className = "",
}: {
  size?: number;
  className?: string;
}) {
  return (
    <svg
      viewBox="0 0 44 26"
      width={size}
      height={(size * 26) / 44}
      className={className}
      fill="currentColor"
      aria-hidden
    >
      <path d="M22 1c4.2 5 4.2 11 0 15.6C17.8 12 17.8 6 22 1z" />
      <path d="M9 5.5c6.4 1.2 10 5.6 10.6 11.4C13 16.4 8.8 12 9 5.5z" />
      <path d="M35 5.5c-6.4 1.2-10 5.6-10.6 11.4C31 16.4 35.2 12 35 5.5z" />
      <path d="M1.5 12.5c5.5-.4 10.7 1.5 14.7 6-6.3 1.4-11.8-1-14.7-6z" />
      <path d="M42.5 12.5c-5.5-.4-10.7 1.5-14.7 6 6.3 1.4 11.8-1 14.7-6z" />
      <path d="M13 22.5c3-1.6 6-2.4 9-2.4s6 .8 9 2.4c-3 1.8-6 2.6-9 2.6s-6-.8-9-2.6z" />
    </svg>
  );
}
