import { motion } from "framer-motion";
import { Link } from "react-router-dom";
import { Heart } from "lucide-react";
import type { Product } from "../data/products";
import { categoryLabels } from "../data/products";
import { EASE, RM, viewportOnce } from "../lib/motion";
import { useFavorites } from "../hooks/useFavorites";
import { useToast } from "./Toast";

interface Props {
  product: Product;
  index?: number;
}

export default function ProductCard({ product, index = 0 }: Props) {
  const { has, toggle } = useFavorites();
  const toast = useToast();
  const liked = has(product.id);
  const formatPrice = (p: number) =>
    new Intl.NumberFormat("fa-IR").format(p) + " تومان";

  return (
    <motion.article
      initial={RM ? false : { opacity: 0, y: 36 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={viewportOnce}
      transition={{ duration: 0.75, delay: RM ? 0 : index * 0.07, ease: EASE }}
      whileHover={RM ? undefined : { y: -6 }}
      className="card-luxury group bg-noir-900 relative"
    >
      <button
        type="button"
        onClick={(e) => {
          e.preventDefault();
          e.stopPropagation();
          toggle(product.id);
          toast(liked ? "از علاقه‌مندی‌ها حذف شد" : "به علاقه‌مندی‌ها اضافه شد");
        }}
        className="absolute top-3 left-3 z-20 w-9 h-9 flex items-center justify-center bg-noir-950/70 border border-ivory/10 text-ivory/70 hover:text-gold-400 hover:border-gold-500/40 transition-colors"
        aria-label="علاقه‌مندی"
      >
        <Heart size={16} fill={liked ? "currentColor" : "none"} className={liked ? "text-gold-500" : ""} />
      </button>

      <Link to={`/product/${product.id}`} className="block">
        <div className="img-zoom relative aspect-[3/4]">
          <motion.img
            src={product.images[0]}
            alt={product.name}
            className="w-full h-full object-cover"
            loading="lazy"
            whileHover={RM ? undefined : { scale: 1.08 }}
            transition={{ duration: 1.1, ease: EASE }}
          />
          <div className="absolute inset-0 overlay-gradient opacity-40 group-hover:opacity-85 transition-opacity duration-500" />
          {product.badge && (
            <span className="absolute top-3 right-3 text-[10px] tracking-wide bg-gold-500 text-noir-950 px-2.5 py-1 font-semibold">
              {product.badge}
            </span>
          )}
          <div className="absolute bottom-0 inset-x-0 p-4 translate-y-2 opacity-0 group-hover:translate-y-0 group-hover:opacity-100 transition-all duration-500">
            <span className="font-latin text-[10px] tracking-[0.3em] text-gold-400 uppercase">
              {categoryLabels[product.category]}
            </span>
          </div>
        </div>
        <div className="p-5 border-t border-gold-500/10">
          <h3 className="font-display text-xl text-ivory mb-1 group-hover:text-gold-400 transition-colors">
            {product.name}
          </h3>
          <p className="text-ivory/40 text-xs mb-3 line-clamp-2 leading-6 font-light">
            {product.description}
          </p>
          <div className="flex items-center justify-between">
            {product.showPrice && product.price ? (
              <span className="text-gold-400 text-sm font-medium">{formatPrice(product.price)}</span>
            ) : (
              <span className="text-ivory/30 text-[11px]">قیمت بر اساس سفارش</span>
            )}
            <span className="text-[10px] text-ivory/30 tracking-wider group-hover:text-gold-500 transition-colors">
              جزئیات ←
            </span>
          </div>
        </div>
      </Link>
    </motion.article>
  );
}
