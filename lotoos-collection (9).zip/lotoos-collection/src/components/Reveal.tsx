import { motion } from "framer-motion";
import type { ReactNode } from "react";
import { EASE, RM, viewportOnce } from "../lib/motion";

type Props = {
  children: ReactNode;
  delay?: number;
  y?: number;
  className?: string;
  as?: "div" | "span" | "section" | "li" | "article";
};

export default function Reveal({
  children,
  delay = 0,
  y = 32,
  className = "",
  as = "div",
}: Props) {
  const Comp = motion[as];
  return (
    <Comp
      className={className}
      initial={RM ? false : { opacity: 0, y }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={viewportOnce}
      transition={{ duration: RM ? 0.01 : 0.9, delay: RM ? 0 : delay, ease: EASE }}
    >
      {children}
    </Comp>
  );
}

/** متن از داخل ماسک بالا می‌آید — حس زنده هیرو */
export function MaskLine({
  children,
  delay = 0,
  className = "",
}: {
  children: ReactNode;
  delay?: number;
  className?: string;
}) {
  return (
    <span className={`block overflow-hidden ${className}`}>
      <motion.span
        className="block"
        initial={RM ? false : { y: "110%" }}
        animate={{ y: 0 }}
        transition={{ duration: RM ? 0.01 : 1.05, delay: RM ? 0 : delay, ease: EASE }}
      >
        {children}
      </motion.span>
    </span>
  );
}
