import { Link } from "react-router-dom";
import { Instagram, Phone, MapPin } from "lucide-react";
import { useSiteSettings } from "../hooks/useSiteSettings";
import Lotus from "./Lotus";
import Marquee from "./Marquee";

export default function Footer() {
  const { settings } = useSiteSettings();
  const phoneDisplay = settings.phone.replace(/(\d{4})(\d{3})(\d{4})/, "$1 $2 $3");
  const phoneHref = settings.phone.startsWith("0")
    ? `+98${settings.phone.slice(1)}`
    : settings.phone;

  return (
    <footer className="relative bg-noir-950 pt-0 pb-10 overflow-hidden">
      <Marquee
        latin
        items={["Lotoos Collection", "Couture", "Bridal", "Evening", "Bespoke", "Atelier"]}
      />

      <div className="max-w-7xl mx-auto px-5 md:px-10 pt-16">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-12 mb-14">
          <div>
            <div className="flex items-center gap-3 mb-5">
              <Lotus size={32} className="text-gold-500" />
              <div>
                <p className="font-latin tracking-[0.3em] text-sm text-ivory" dir="ltr">
                  LOTOOS
                </p>
                <p className="text-[9px] text-gold-500/70 tracking-widest uppercase">Collection</p>
              </div>
            </div>
            <p className="text-ivory/45 text-sm leading-8 max-w-xs font-light">
              {settings.tagline}
            </p>
            <p className="font-nastaliq text-gold-500/70 text-sm mt-5">دوختِ دست، امضای ماست</p>
          </div>

          <div>
            <h4 className="font-latin text-[11px] tracking-[0.35em] text-gold-500 uppercase mb-6">
              Explore
            </h4>
            <ul className="space-y-3.5 text-sm text-ivory/55">
              {[
                ["/collections", "کالکشن‌ها"],
                ["/gallery", "گالری"],
                ["/custom-order", "سفارش اختصاصی"],
                ["/appointment", "رزرو مشاوره"],
                ["/track", "پیگیری سفارش"],
                ["/favorites", "علاقه‌مندی‌ها"],
                ["/about", "داستان برند"],
                ["/contact", "تماس و آدرس"],
              ].map(([to, label]) => (
                <li key={to}>
                  <Link to={to} className="hover:text-gold-400 transition-colors">
                    {label}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          <div>
            <h4 className="font-latin text-[11px] tracking-[0.35em] text-gold-500 uppercase mb-6">
              Contact
            </h4>
            <ul className="space-y-4 text-sm text-ivory/55">
              <li className="flex items-center gap-3">
                <Phone size={14} className="text-gold-500 shrink-0" />
                <a href={`tel:${phoneHref}`} className="hover:text-gold-400" dir="ltr">
                  {phoneDisplay}
                </a>
              </li>
              <li className="flex items-center gap-3">
                <Instagram size={14} className="text-gold-500 shrink-0" />
                <a
                  href={`https://instagram.com/${settings.instagram.replace("@", "")}`}
                  target="_blank"
                  rel="noreferrer"
                  className="hover:text-gold-400"
                >
                  @{settings.instagram.replace("@", "")}
                </a>
              </li>
              <li className="flex items-start gap-3">
                <MapPin size={14} className="text-gold-500 shrink-0 mt-0.5" />
                <span className="leading-7">{settings.address}</span>
              </li>
            </ul>
          </div>
        </div>

        <div className="hairline mb-8" />
        <div className="flex flex-col sm:flex-row justify-between items-center gap-3 text-[11px] text-ivory/30">
          <p>© ۱۴۰۵ {settings.brandName}</p>
          <p className="font-latin tracking-[0.35em] text-gold-600/50 uppercase text-[10px]" dir="ltr">
            Handcrafted in Tehran
          </p>
        </div>
      </div>
    </footer>
  );
}
