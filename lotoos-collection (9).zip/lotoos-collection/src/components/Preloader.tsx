import { motion, AnimatePresence } from "framer-motion";
import { useEffect, useState } from "react";
import Lotus from "./Lotus";
import { EASE, RM } from "../lib/motion";

export default function Preloader() {
  const [show, setShow] = useState(true);
  const [progress, setProgress] = useState(0);

  useEffect(() => {
    if (RM) {
      setShow(false);
      return;
    }
    let p = 0;
    const id = setInterval(() => {
      p += Math.random() * 18 + 8;
      if (p >= 100) {
        p = 100;
        setProgress(100);
        clearInterval(id);
        setTimeout(() => setShow(false), 420);
      } else setProgress(Math.min(100, Math.floor(p)));
    }, 120);
    return () => clearInterval(id);
  }, []);

  return (
    <AnimatePresence>
      {show && (
        <motion.div
          className="fixed inset-0 z-[200] bg-noir-950 flex flex-col items-center justify-center"
          exit={{ opacity: 0, transition: { duration: 0.6, ease: EASE } }}
        >
          <motion.div
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.7, ease: EASE }}
            className="flex flex-col items-center gap-6"
          >
            <Lotus size={48} className="text-gold-500" />
            <p className="font-latin tracking-[0.45em] text-sm text-ivory/80" dir="ltr">
              LOTOOS
            </p>
            <div className="w-40 h-px bg-noir-800 relative overflow-hidden">
              <motion.div
                className="absolute inset-y-0 right-0 bg-gold-500"
                style={{ width: `${progress}%` }}
              />
            </div>
            <p className="text-[10px] tracking-[0.3em] text-ivory/30 font-latin" dir="ltr">
              {progress}%
            </p>
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}
