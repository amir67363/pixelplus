import { motion } from "framer-motion";
import { Link } from "react-router-dom";
import { useSiteSettings } from "../hooks/useSiteSettings";
import Reveal from "./Reveal";
import { EASE, RM } from "../lib/motion";

export default function AboutPreview() {
  const { settings } = useSiteSettings();
  const preview = settings.aboutText.split(/\n\n+/)[0] || settings.aboutText;

  return (
    <section className="py-24 md:py-32 bg-noir-950 overflow-hidden">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-14 lg:gap-20 items-center">
          <Reveal y={40} className="relative">
            <div className="aspect-[4/5] overflow-hidden">
              <motion.img
                src={settings.aboutImage}
                alt={settings.aboutTitle}
                className="w-full h-full object-cover"
                whileHover={RM ? undefined : { scale: 1.05 }}
                transition={{ duration: 1.2, ease: EASE }}
              />
            </div>
            <div className="absolute -bottom-4 -left-4 w-32 h-32 border border-gold-500/25 hidden md:block pointer-events-none" />
          </Reveal>

          <div>
            <Reveal>
              <div className="flex items-center gap-4 mb-4">
                <span className="h-px w-12 bg-gold-500/70" />
                <span className="font-latin tracking-[.4em] text-[11px] uppercase text-gold-500">
                  Our Story
                </span>
              </div>
              <h2 className="section-title mb-7">{settings.aboutTitle}</h2>
            </Reveal>
            <Reveal delay={0.1}>
              <div className="space-y-5 text-ivory/60 text-sm leading-8 font-light">
                <p>{preview}</p>
                <p className="text-gold-400/90 font-normal">
                  کیفیت، ظرافت و کار دست — سه اصل غیرقابل مذاکره لوتوس.
                </p>
              </div>
            </Reveal>
            <Reveal delay={0.2}>
              <Link to="/about" className="btn-outline mt-9 inline-flex">
                بیشتر درباره ما
              </Link>
            </Reveal>
          </div>
        </div>
      </div>
    </section>
  );
}
