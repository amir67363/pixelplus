import { Link } from "react-router-dom";
import { motion } from "framer-motion";
import { type Category, categoryLabels } from "../data/products";
import ProductCard from "./ProductCard";
import { ArrowLeft } from "lucide-react";
import { useProducts } from "../hooks/useProducts";
import Reveal from "./Reveal";
import { EASE, RM, viewportOnce } from "../lib/motion";

const categories: { key: Category; label: string; image: string }[] = [
  {
    key: "mjlsi",
    label: "لباس مجلسی",
    image: "https://images.unsplash.com/photo-1595777457583-95e059d581b8?w=700&q=80",
  },
  {
    key: "aroos",
    label: "لباس عروس",
    image: "https://images.unsplash.com/photo-1515372039744-b8f02a3ae446?w=700&q=80",
  },
  {
    key: "aghd",
    label: "لباس عقد",
    image: "https://images.unsplash.com/photo-1469334031218-e382a71b716b?w=700&q=80",
  },
  {
    key: "custom",
    label: "طراحی اختصاصی",
    image: "https://images.unsplash.com/photo-1558171813-4c088753af8f?w=700&q=80",
  },
];

export default function CollectionSection() {
  const { products } = useProducts();
  const featured = products.filter((p) => p.featured).slice(0, 4);

  return (
    <section id="collections" className="py-24 md:py-32 bg-noir-950 relative">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <Reveal>
          <div className="mb-14">
            <div className="flex items-center gap-4 mb-4">
              <span className="h-px w-12 bg-gold-500/70" />
              <span className="font-latin tracking-[.4em] text-[11px] uppercase text-gold-500">
                Collections
              </span>
            </div>
            <h2 className="section-title">کالکشن‌های لوتوس</h2>
          </div>
        </Reveal>

        <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 md:gap-4 mb-24">
          {categories.map((cat, i) => (
            <motion.div
              key={cat.key}
              initial={RM ? false : { opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={viewportOnce}
              transition={{ delay: RM ? 0 : i * 0.09, duration: 0.7, ease: EASE }}
            >
              <Link
                to={`/collections?cat=${cat.key}`}
                className="group relative block aspect-[3/4] overflow-hidden"
              >
                <motion.img
                  src={cat.image}
                  alt={cat.label}
                  className="w-full h-full object-cover"
                  whileHover={RM ? undefined : { scale: 1.1 }}
                  transition={{ duration: 1.1, ease: EASE }}
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/85 via-black/30 to-transparent group-hover:from-black/90 transition-all duration-500" />
                <div className="absolute inset-0 flex items-end p-5 md:p-6">
                  <div>
                    <p className="font-latin text-gold-400/90 text-[9px] tracking-[0.35em] uppercase mb-1.5">
                      Collection
                    </p>
                    <h3 className="text-ivory text-base md:text-lg font-display tracking-wide">
                      {categoryLabels[cat.key] || cat.label}
                    </h3>
                  </div>
                </div>
              </Link>
            </motion.div>
          ))}
        </div>

        <div className="mb-10 flex items-end justify-between gap-4">
          <Reveal>
            <div>
              <p className="section-subtitle">Featured</p>
              <h3 className="font-display text-3xl md:text-4xl text-ivory">منتخب‌ها</h3>
            </div>
          </Reveal>
          <Reveal delay={0.1}>
            <Link
              to="/collections"
              className="hidden sm:inline-flex items-center gap-2 text-sm text-gold-400/80 hover:text-gold-300 tracking-wide transition-colors group"
            >
              مشاهده همه
              <ArrowLeft size={16} className="group-hover:-translate-x-1 transition-transform" />
            </Link>
          </Reveal>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-5 md:gap-6">
          {featured.map((p, i) => (
            <ProductCard key={p.id} product={p} index={i} />
          ))}
        </div>
      </div>
    </section>
  );
}
