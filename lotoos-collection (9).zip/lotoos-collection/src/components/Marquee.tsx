export default function Marquee({
  items,
  reverse = false,
  latin = false,
}: {
  items: string[];
  reverse?: boolean;
  latin?: boolean;
}) {
  return (
    <div className="overflow-hidden border-y border-gold-500/15 bg-noir-900 py-4" dir="ltr">
      <div className={`mq ${reverse ? "mq-rev" : ""}`}>
        {[0, 1].map((k) => (
          <div key={k} className="flex shrink-0 items-center">
            {items.map((t, i) => (
              <span
                key={i}
                className={`flex items-center whitespace-nowrap ${
                  latin
                    ? "font-latin tracking-[.45em] text-xs uppercase text-ivory/45"
                    : "font-display text-2xl text-gold-400/85"
                }`}
              >
                <span className="px-6">{t}</span>
                <span className="text-gold-600 text-sm">✦</span>
              </span>
            ))}
          </div>
        ))}
      </div>
    </div>
  );
}
