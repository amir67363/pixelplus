import { useState, type FormEvent } from "react";
import { motion } from "framer-motion";
import { Eye, EyeOff, ShieldAlert, Sparkles } from "lucide-react";
import { login, isLocked } from "./auth";

interface Props {
  onSuccess: () => void;
}

export default function AdminLogin({ onSuccess }: Props) {
  const [password, setPassword] = useState("");
  const [show, setShow] = useState(false);
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);
  const lock = isLocked();

  const handleSubmit = async (e: FormEvent) => {
    e.preventDefault();
    setError("");
    setLoading(true);
    try {
      const result = await login(password);
      if (result.ok) onSuccess();
      else {
        setError(result.error || "ورود ناموفق");
        setPassword("");
      }
    } catch {
      setError("خطای غیرمنتظره.");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen relative overflow-hidden flex items-center justify-center px-4">
      {/* soft ambient background */}
      <div className="absolute inset-0 bg-matte-black" />
      <div
        className="absolute inset-0 opacity-30"
        style={{
          background:
            "radial-gradient(ellipse 80% 50% at 50% -20%, rgba(212,175,55,0.25), transparent), radial-gradient(ellipse 60% 40% at 80% 100%, rgba(212,175,55,0.08), transparent)",
        }}
      />
      <div className="absolute top-1/4 right-1/4 w-64 h-64 rounded-full bg-champagne/5 blur-3xl" />
      <div className="absolute bottom-1/3 left-1/5 w-48 h-48 rounded-full bg-champagne/5 blur-3xl" />

      <motion.div
        initial={{ opacity: 0, y: 28 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.6, ease: [0.22, 1, 0.36, 1] }}
        className="relative w-full max-w-md"
      >
        <div className="text-center mb-10">
          <motion.div
            initial={{ scale: 0.8, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            transition={{ delay: 0.15, duration: 0.5 }}
            className="inline-flex items-center justify-center w-16 h-16 rounded-full border border-champagne/30 bg-champagne/5 mb-6"
          >
            <Sparkles className="text-champagne" size={24} />
          </motion.div>
          <p className="text-champagne/80 text-[11px] tracking-[0.4em] uppercase mb-3">
            Lotoos Atelier
          </p>
          <h1 className="text-3xl font-light text-cream tracking-wide">خوش آمدید</h1>
          <p className="text-cream/40 text-sm mt-2">ورود به فضای مدیریت برند</p>
        </div>

        <form
          onSubmit={handleSubmit}
          className="rounded-2xl border border-white/8 bg-white/[0.03] backdrop-blur-xl p-8 shadow-2xl shadow-black/40 space-y-6"
        >
          {lock.locked && (
            <div className="flex items-start gap-3 rounded-xl bg-red-500/10 border border-red-500/25 px-4 py-3.5 text-sm text-red-300">
              <ShieldAlert size={18} className="shrink-0 mt-0.5" />
              <span>
                پنل قفل است. حدود {Math.ceil(lock.remainingMs / 60000)} دقیقه دیگر دوباره تلاش کنید.
              </span>
            </div>
          )}

          <div>
            <label className="block text-[11px] text-cream/45 mb-2.5 tracking-[0.15em] uppercase">
              رمز عبور
            </label>
            <div className="relative group">
              <input
                type={show ? "text" : "password"}
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                className="w-full bg-black/40 border border-white/10 rounded-xl px-5 py-3.5 pl-12 text-cream placeholder:text-white/25 focus:outline-none focus:border-champagne/50 focus:ring-1 focus:ring-champagne/20 transition-all duration-300"
                placeholder="رمز خود را وارد کنید"
                autoComplete="current-password"
                disabled={lock.locked || loading}
                required
                minLength={6}
              />
              <button
                type="button"
                onClick={() => setShow(!show)}
                className="absolute left-4 top-1/2 -translate-y-1/2 text-cream/35 hover:text-champagne transition-colors"
                tabIndex={-1}
              >
                {show ? <EyeOff size={18} /> : <Eye size={18} />}
              </button>
            </div>
          </div>

          {error && (
            <motion.p
              initial={{ opacity: 0, y: -4 }}
              animate={{ opacity: 1, y: 0 }}
              className="text-red-400/90 text-xs text-center leading-relaxed"
            >
              {error}
            </motion.p>
          )}

          <button
            type="submit"
            disabled={lock.locked || loading}
            className="w-full rounded-xl bg-gradient-to-l from-champagne to-champagne-dark text-matte-black font-medium py-3.5 text-sm tracking-widest transition-all duration-300 hover:shadow-lg hover:shadow-champagne/20 disabled:opacity-40 disabled:cursor-not-allowed disabled:hover:shadow-none"
          >
            {loading ? (
              <span className="inline-flex items-center gap-2">
                <span className="w-4 h-4 border-2 border-matte-black/30 border-t-matte-black rounded-full animate-spin" />
                در حال ورود...
              </span>
            ) : (
              "ورود به پنل"
            )}
          </button>
        </form>

        <p className="text-center text-[10px] text-cream/20 mt-8 tracking-wider">
          نشست امن · انقضا پس از ۴ ساعت عدم فعالیت
        </p>
      </motion.div>
    </div>
  );
}
