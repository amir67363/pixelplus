import { useState, useEffect, useCallback, type FormEvent } from "react";
import { motion, AnimatePresence } from "framer-motion";
import {
  Plus, Trash2, Edit2, Image, Package, MessageSquare, LayoutGrid,
  LogOut, Settings, X, Check, Eye, EyeOff, Search, Bell,
  TrendingUp, ShoppingBag, Mail, Images, KeyRound, Save,
} from "lucide-react";
import AdminLogin from "./AdminLogin";
import { isAuthenticated, logout, touchSession, changePassword } from "./auth";
import {
  store,
  type Product,
  type CustomOrder,
  type CustomerMessage,
  type GalleryItem,
  type SiteSettings,
  type OrderStatus,
  type TestimonialItem,
  categoryLabels,
  type Category,
  buildMapEmbedUrl,
  buildMapLink,
} from "./store";
import { notifySettingsChanged } from "../hooks/useSiteSettings";
import { notifyProductsChanged } from "../hooks/useProducts";
import { notifyGalleryChanged } from "../hooks/useGallery";
import { notifyTestimonialsChanged } from "../hooks/useTestimonials";

type Tab = "overview" | "products" | "orders" | "messages" | "gallery" | "settings";

const statusLabel: Record<OrderStatus, string> = {
  new: "جدید",
  reviewing: "در بررسی",
  in_progress: "در حال دوخت",
  done: "تمام‌شده",
  cancelled: "لغو",
};

const statusColor: Record<OrderStatus, string> = {
  new: "bg-champagne/20 text-champagne",
  reviewing: "bg-blue-500/20 text-blue-300",
  in_progress: "bg-amber-500/20 text-amber-300",
  done: "bg-emerald-500/20 text-emerald-300",
  cancelled: "bg-red-500/20 text-red-300",
};

const emptyProduct = (): Product => ({
  id: crypto.randomUUID(),
  name: "",
  category: "mjlsi",
  description: "",
  fabric: "",
  colors: [],
  sizes: [],
  price: null,
  showPrice: true,
  images: [""],
  featured: false,
});

export default function AdminPanel() {
  const [authed, setAuthed] = useState(false);
  const [checking, setChecking] = useState(true);
  const [tab, setTab] = useState<Tab>("overview");

  const [products, setProducts] = useState<Product[]>([]);
  const [orders, setOrders] = useState<CustomOrder[]>([]);
  const [messages, setMessages] = useState<CustomerMessage[]>([]);
  const [gallery, setGallery] = useState<GalleryItem[]>([]);
  const [settings, setSettings] = useState<SiteSettings>(store.getSettings());
  const [testimonials, setTestimonials] = useState<TestimonialItem[]>([]);

  const [search, setSearch] = useState("");
  const [editing, setEditing] = useState<Product | null>(null);
  const [editingOrder, setEditingOrder] = useState<CustomOrder | null>(null);
  const [toast, setToast] = useState("");

  // password form
  const [pwdForm, setPwdForm] = useState({ current: "", next: "", confirm: "" });
  const [showPwd, setShowPwd] = useState(false);
  const [pwdMsg, setPwdMsg] = useState("");

  const showToast = (msg: string) => {
    setToast(msg);
    setTimeout(() => setToast(""), 2800);
  };

  useEffect(() => {
    setAuthed(isAuthenticated());
    setChecking(false);
    if (isAuthenticated()) {
      setProducts(store.getProducts());
      setOrders(store.getOrders());
      setMessages(store.getMessages());
      setGallery(store.getGallery());
      setSettings(store.getSettings());
      setTestimonials(store.getTestimonials());
    }
  }, []);

  useEffect(() => {
    if (!authed) return;
    const onAct = () => touchSession();
    window.addEventListener("click", onAct);
    window.addEventListener("keydown", onAct);
    const id = setInterval(() => {
      if (!isAuthenticated()) setAuthed(false);
    }, 60_000);
    return () => {
      window.removeEventListener("click", onAct);
      window.removeEventListener("keydown", onAct);
      clearInterval(id);
    };
  }, [authed]);

  const persistProducts = (list: Product[]) => {
    setProducts(list);
    store.setProducts(list);
    notifyProductsChanged();
  };
  const persistOrders = (list: CustomOrder[]) => {
    setOrders(list);
    store.setOrders(list);
  };
  const persistMessages = (list: CustomerMessage[]) => {
    setMessages(list);
    store.setMessages(list);
  };
  const persistGallery = (list: GalleryItem[]) => {
    setGallery(list);
    store.setGallery(list);
    notifyGalleryChanged();
  };
  const persistSettings = (s: SiteSettings) => {
    setSettings(s);
    store.setSettings(s);
    notifySettingsChanged();
  };
  const persistTestimonials = (list: TestimonialItem[]) => {
    setTestimonials(list);
    store.setTestimonials(list);
    notifyTestimonialsChanged();
  };

  const handleLogout = useCallback(() => {
    logout();
    setAuthed(false);
  }, []);

  const saveProduct = (e: FormEvent) => {
    e.preventDefault();
    if (!editing) return;
    if (!editing.name.trim()) {
      showToast("نام محصول الزامی است");
      return;
    }
    const exists = products.find((p) => p.id === editing.id);
    const next = exists
      ? products.map((p) => (p.id === editing.id ? editing : p))
      : [editing, ...products];
    persistProducts(next);
    setEditing(null);
    showToast(exists ? "محصول به‌روز شد" : "محصول اضافه شد");
  };

  const deleteProduct = (id: string) => {
    if (!confirm("حذف این محصول؟")) return;
    persistProducts(products.filter((p) => p.id !== id));
    showToast("محصول حذف شد");
  };

  const updateOrderStatus = (id: string, status: OrderStatus) => {
    persistOrders(
      orders.map((o) =>
        o.id === id ? { ...o, status, updatedAt: new Date().toISOString() } : o
      )
    );
    showToast("وضعیت سفارش به‌روز شد");
  };

  const saveOrderDetails = (e: FormEvent) => {
    e.preventDefault();
    if (!editingOrder) return;
    persistOrders(
      orders.map((o) =>
        o.id === editingOrder.id
          ? { ...editingOrder, updatedAt: new Date().toISOString() }
          : o
      )
    );
    setEditingOrder(null);
    showToast("جزئیات سفارش برای مشتری ذخیره شد");
  };

  const deleteOrder = (id: string) => {
    if (!confirm("حذف این سفارش؟")) return;
    persistOrders(orders.filter((o) => o.id !== id));
    showToast("سفارش حذف شد");
  };

  const markRead = (id: string) => {
    persistMessages(messages.map((m) => (m.id === id ? { ...m, read: true } : m)));
  };

  const deleteMessage = (id: string) => {
    persistMessages(messages.filter((m) => m.id !== id));
    showToast("پیام حذف شد");
  };

  const addGalleryItem = () => {
    const url = prompt("آدرس تصویر (URL):");
    if (!url) return;
    const item: GalleryItem = {
      id: crypto.randomUUID(),
      src: url,
      alt: "گالری",
      type: "image",
      createdAt: new Date().toISOString(),
    };
    persistGallery([item, ...gallery]);
    showToast("تصویر اضافه شد");
  };

  const deleteGalleryItem = (id: string) => {
    if (!confirm("حذف از گالری؟")) return;
    persistGallery(gallery.filter((g) => g.id !== id));
    showToast("حذف شد");
  };

  const handleChangePassword = async (e: FormEvent) => {
    e.preventDefault();
    setPwdMsg("");
    if (pwdForm.next !== pwdForm.confirm) {
      setPwdMsg("تکرار رمز با رمز جدید یکی نیست.");
      return;
    }
    const res = await changePassword(pwdForm.current, pwdForm.next);
    if (res.ok) {
      setPwdMsg("رمز با موفقیت عوض شد.");
      setPwdForm({ current: "", next: "", confirm: "" });
      showToast("رمز عبور تغییر کرد");
    } else {
      setPwdMsg(res.error || "خطا");
    }
  };

  const filteredProducts = products.filter(
    (p) =>
      !search ||
      p.name.includes(search) ||
      p.fabric.includes(search) ||
      categoryLabels[p.category]?.includes(search)
  );

  const unread = messages.filter((m) => !m.read).length;
  const newOrders = orders.filter((o) => o.status === "new").length;

  if (checking) {
    return (
      <div className="min-h-screen bg-matte-black flex items-center justify-center">
        <div className="w-9 h-9 border-2 border-champagne/30 border-t-champagne rounded-full animate-spin" />
      </div>
    );
  }
  if (!authed) return <AdminLogin onSuccess={() => {
    setAuthed(true);
    setProducts(store.getProducts());
    setOrders(store.getOrders());
    setMessages(store.getMessages());
    setGallery(store.getGallery());
    setSettings(store.getSettings());
    setTestimonials(store.getTestimonials());
  }} />;

  const nav: { key: Tab; label: string; icon: typeof Package; badge?: number }[] = [
    { key: "overview", label: "نمای کلی", icon: TrendingUp },
    { key: "products", label: "محصولات", icon: Package },
    { key: "orders", label: "سفارش‌ها", icon: ShoppingBag, badge: newOrders },
    { key: "messages", label: "پیام‌ها", icon: Mail, badge: unread },
    { key: "gallery", label: "گالری", icon: Images },
    { key: "settings", label: "تنظیمات", icon: Settings },
  ];

  return (
    <div className="min-h-screen bg-[#0c0c0c] flex">
      {/* Sidebar */}
      <aside className="hidden lg:flex w-60 flex-col border-l border-white/5 bg-[#111] fixed top-0 bottom-0 right-0 z-40 pt-20">
        <div className="px-5 mb-6">
          <p className="text-champagne text-[10px] tracking-[0.3em] uppercase">Lotoos</p>
          <p className="text-cream/50 text-xs mt-0.5">پنل مدیریت</p>
        </div>
        <nav className="flex-1 px-3 space-y-1">
          {nav.map((n) => (
            <button
              key={n.key}
              onClick={() => setTab(n.key)}
              className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl text-sm transition-all duration-300 ${
                tab === n.key
                  ? "bg-champagne/15 text-champagne"
                  : "text-cream/50 hover:text-cream hover:bg-white/5"
              }`}
            >
              <n.icon size={18} />
              <span className="flex-1 text-right">{n.label}</span>
              {n.badge ? (
                <span className="min-w-[20px] h-5 rounded-full bg-champagne text-matte-black text-[10px] font-medium flex items-center justify-center px-1.5">
                  {n.badge}
                </span>
              ) : null}
            </button>
          ))}
        </nav>
        <div className="p-4 border-t border-white/5">
          <button
            onClick={handleLogout}
            className="w-full flex items-center gap-3 px-4 py-3 rounded-xl text-sm text-cream/40 hover:text-red-300 hover:bg-red-500/10 transition-all"
          >
            <LogOut size={18} />
            خروج امن
          </button>
        </div>
      </aside>

      {/* Main */}
      <div className="flex-1 lg:mr-60 pt-20 pb-24 lg:pb-10">
        {/* Top bar mobile tabs */}
        <div className="lg:hidden sticky top-16 z-30 bg-[#0c0c0c]/95 backdrop-blur border-b border-white/5 px-3 py-2 overflow-x-auto flex gap-2">
          {nav.map((n) => (
            <button
              key={n.key}
              onClick={() => setTab(n.key)}
              className={`shrink-0 flex items-center gap-1.5 px-3 py-2 rounded-lg text-xs ${
                tab === n.key ? "bg-champagne/15 text-champagne" : "text-cream/50"
              }`}
            >
              <n.icon size={14} />
              {n.label}
              {n.badge ? (
                <span className="w-4 h-4 rounded-full bg-champagne text-matte-black text-[9px] flex items-center justify-center">
                  {n.badge}
                </span>
              ) : null}
            </button>
          ))}
        </div>

        <div className="max-w-6xl mx-auto px-4 sm:px-6 pt-6">
          {/* OVERVIEW */}
          {tab === "overview" && (
            <div className="space-y-8">
              <div>
                <h1 className="text-2xl font-light text-cream">سلام 👋</h1>
                <p className="text-cream/40 text-sm mt-1">خلاصه وضعیت برند امروز</p>
              </div>
              <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
                {[
                  { label: "محصولات", value: products.length, icon: Package, color: "text-champagne" },
                  { label: "سفارش جدید", value: newOrders, icon: ShoppingBag, color: "text-amber-300" },
                  { label: "پیام خوانده‌نشده", value: unread, icon: Bell, color: "text-blue-300" },
                  { label: "گالری", value: gallery.length, icon: Images, color: "text-emerald-300" },
                ].map((c) => (
                  <motion.div
                    key={c.label}
                    initial={{ opacity: 0, y: 12 }}
                    animate={{ opacity: 1, y: 0 }}
                    className="rounded-2xl border border-white/6 bg-white/[0.03] p-5"
                  >
                    <c.icon size={20} className={`${c.color} mb-3 opacity-80`} />
                    <p className="text-2xl font-light text-cream">{c.value}</p>
                    <p className="text-xs text-cream/40 mt-1">{c.label}</p>
                  </motion.div>
                ))}
              </div>

              <div className="grid lg:grid-cols-2 gap-6">
                <div className="rounded-2xl border border-white/6 bg-white/[0.03] p-6">
                  <h3 className="text-cream text-sm mb-4 flex items-center gap-2">
                    <ShoppingBag size={16} className="text-champagne" /> آخرین سفارش‌ها
                  </h3>
                  <div className="space-y-3">
                    {orders.slice(0, 4).map((o) => (
                      <div key={o.id} className="flex items-center justify-between gap-3 text-sm">
                        <div>
                          <p className="text-cream">{o.name}</p>
                          <p className="text-cream/35 text-xs">{o.type}</p>
                        </div>
                        <span className={`text-[10px] px-2 py-1 rounded-full ${statusColor[o.status]}`}>
                          {statusLabel[o.status]}
                        </span>
                      </div>
                    ))}
                    {orders.length === 0 && <p className="text-cream/30 text-sm">سفارشی نیست</p>}
                  </div>
                </div>
                <div className="rounded-2xl border border-white/6 bg-white/[0.03] p-6">
                  <h3 className="text-cream text-sm mb-4 flex items-center gap-2">
                    <Mail size={16} className="text-champagne" /> پیام‌های اخیر
                  </h3>
                  <div className="space-y-3">
                    {messages.slice(0, 4).map((m) => (
                      <div key={m.id} className="text-sm">
                        <div className="flex items-center gap-2">
                          {!m.read && <span className="w-1.5 h-1.5 rounded-full bg-champagne" />}
                          <p className="text-cream">{m.name}</p>
                        </div>
                        <p className="text-cream/35 text-xs line-clamp-1 mt-0.5">{m.body}</p>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* PRODUCTS */}
          {tab === "products" && (
            <div className="space-y-6">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                <div>
                  <h1 className="text-2xl font-light text-cream">محصولات</h1>
                  <p className="text-cream/40 text-sm mt-1">{products.length} آیتم</p>
                </div>
                <div className="flex gap-3">
                  <div className="relative flex-1 sm:flex-none">
                    <Search size={16} className="absolute right-3 top-1/2 -translate-y-1/2 text-cream/30" />
                    <input
                      value={search}
                      onChange={(e) => setSearch(e.target.value)}
                      placeholder="جستجو..."
                      className="w-full sm:w-52 bg-white/5 border border-white/10 rounded-xl pr-10 pl-4 py-2.5 text-sm text-cream placeholder:text-cream/30 focus:outline-none focus:border-champagne/40"
                    />
                  </div>
                  <button
                    onClick={() => setEditing(emptyProduct())}
                    className="shrink-0 flex items-center gap-2 rounded-xl bg-champagne text-matte-black px-4 py-2.5 text-sm font-medium hover:bg-champagne-light transition-colors"
                  >
                    <Plus size={16} />
                    جدید
                  </button>
                </div>
              </div>

              <div className="grid sm:grid-cols-2 xl:grid-cols-3 gap-4">
                {filteredProducts.map((p) => (
                  <motion.div
                    key={p.id}
                    layout
                    className="rounded-2xl border border-white/6 bg-white/[0.03] overflow-hidden group"
                  >
                    <div className="aspect-[4/3] relative overflow-hidden">
                      <img
                        src={p.images[0] || "https://placehold.co/400x300/1a1a1a/666?text=No+Image"}
                        alt={p.name}
                        className="w-full h-full object-cover"
                      />
                      {p.featured && (
                        <span className="absolute top-3 right-3 text-[10px] bg-champagne text-matte-black px-2 py-0.5 rounded-full">
                          ویژه
                        </span>
                      )}
                    </div>
                    <div className="p-4">
                      <p className="text-[10px] text-champagne/70 tracking-wider mb-1">
                        {categoryLabels[p.category]}
                      </p>
                      <h3 className="text-cream font-light mb-1">{p.name}</h3>
                      <p className="text-cream/35 text-xs line-clamp-1 mb-3">{p.fabric}</p>
                      <div className="flex items-center justify-between">
                        <span className="text-champagne/80 text-sm">
                          {p.showPrice && p.price
                            ? new Intl.NumberFormat("fa-IR").format(p.price) + " ت"
                            : "قیمت مخفی"}
                        </span>
                        <div className="flex gap-1 opacity-70 group-hover:opacity-100 transition-opacity">
                          <button
                            onClick={() => setEditing({ ...p })}
                            className="p-2 rounded-lg hover:bg-white/10 text-cream/50 hover:text-champagne"
                          >
                            <Edit2 size={14} />
                          </button>
                          <button
                            onClick={() => deleteProduct(p.id)}
                            className="p-2 rounded-lg hover:bg-red-500/10 text-cream/50 hover:text-red-300"
                          >
                            <Trash2 size={14} />
                          </button>
                        </div>
                      </div>
                    </div>
                  </motion.div>
                ))}
              </div>
              {filteredProducts.length === 0 && (
                <p className="text-center text-cream/30 py-16">محصولی پیدا نشد</p>
              )}
            </div>
          )}

          {/* ORDERS */}
          {tab === "orders" && (
            <div className="space-y-6">
              <div>
                <h1 className="text-2xl font-light text-cream">سفارش‌های اختصاصی</h1>
                <p className="text-cream/40 text-sm mt-1">
                  {orders.length} درخواست · قیمت و توضیح برای مشتری از اینجا تنظیم می‌شود
                </p>
              </div>
              <div className="space-y-3">
                {orders.map((o) => (
                  <div
                    key={o.id}
                    className="rounded-2xl border border-white/6 bg-white/[0.03] p-5 space-y-4"
                  >
                    <div className="flex flex-col md:flex-row md:items-start gap-4">
                      <div className="flex-1 min-w-0">
                        <div className="flex flex-wrap items-center gap-2 mb-1">
                          <p className="text-cream font-medium">{o.name}</p>
                          <span className={`text-[10px] px-2 py-0.5 rounded-full ${statusColor[o.status]}`}>
                            {statusLabel[o.status]}
                          </span>
                          <span className="text-[10px] text-champagne/70 tracking-wider" dir="ltr">
                            {o.trackingCode || "—"}
                          </span>
                        </div>
                        <p className="text-cream/50 text-xs">
                          {o.type} · سایز {o.size} · {o.color}
                        </p>
                        <p className="text-cream/35 text-xs mt-2 line-clamp-2">{o.notes}</p>
                        <p className="text-cream/25 text-[10px] mt-2" dir="ltr">
                          {o.phone} · {new Date(o.createdAt).toLocaleDateString("fa-IR")}
                        </p>
                        {o.quotedPrice != null && (
                          <p className="text-champagne text-sm mt-2">
                            قیمت: {new Intl.NumberFormat("fa-IR").format(o.quotedPrice)} ت
                          </p>
                        )}
                        {o.adminNote && (
                          <p className="text-cream/45 text-xs mt-1 line-clamp-2 border-r-2 border-champagne/30 pr-2">
                            {o.adminNote}
                          </p>
                        )}
                      </div>
                      <div className="flex flex-wrap items-center gap-2 shrink-0">
                        <select
                          value={o.status}
                          onChange={(e) => updateOrderStatus(o.id, e.target.value as OrderStatus)}
                          className="bg-black/40 border border-white/10 rounded-lg px-3 py-2 text-xs text-cream focus:outline-none focus:border-champagne/40"
                        >
                          {(Object.keys(statusLabel) as OrderStatus[]).map((s) => (
                            <option key={s} value={s}>{statusLabel[s]}</option>
                          ))}
                        </select>
                        <button
                          type="button"
                          onClick={() =>
                            setEditingOrder({
                              ...o,
                              quotedPrice: o.quotedPrice ?? null,
                              adminNote: o.adminNote || "",
                              estimatedReady: o.estimatedReady || "",
                              trackingCode: o.trackingCode || "",
                            })
                          }
                          className="px-3 py-2 rounded-lg border border-champagne/40 text-champagne text-xs hover:bg-champagne/10"
                        >
                          قیمت / توضیح
                        </button>
                        <button
                          type="button"
                          onClick={() => {
                            const url = `${window.location.origin}/track?code=${o.trackingCode}`;
                            navigator.clipboard?.writeText(url);
                            showToast("لینک پیگیری کپی شد");
                          }}
                          className="px-3 py-2 rounded-lg border border-white/10 text-cream/50 text-xs hover:text-cream"
                        >
                          کپی لینک
                        </button>
                        <button
                          type="button"
                          onClick={() => deleteOrder(o.id)}
                          className="p-2 rounded-lg hover:bg-red-500/10 text-cream/40 hover:text-red-300"
                        >
                          <Trash2 size={15} />
                        </button>
                      </div>
                    </div>
                  </div>
                ))}
                {orders.length === 0 && (
                  <p className="text-center text-cream/30 py-16">هنوز سفارشی ثبت نشده</p>
                )}
              </div>
            </div>
          )}

          {tab === "messages" && (
            <div className="space-y-6">
              <div>
                <h1 className="text-2xl font-light text-cream">پیام مشتریان</h1>
                <p className="text-cream/40 text-sm mt-1">
                  {unread > 0 ? `${unread} خوانده‌نشده` : "همه خوانده شده"}
                </p>
              </div>
              <div className="space-y-3">
                {messages.map((m) => (
                  <div
                    key={m.id}
                    onClick={() => markRead(m.id)}
                    className={`rounded-2xl border p-5 cursor-pointer transition-colors ${
                      m.read
                        ? "border-white/5 bg-white/[0.02]"
                        : "border-champagne/20 bg-champagne/5"
                    }`}
                  >
                    <div className="flex items-start justify-between gap-3">
                      <div>
                        <div className="flex items-center gap-2 mb-1">
                          {!m.read && <span className="w-2 h-2 rounded-full bg-champagne" />}
                          <p className="text-cream text-sm font-medium">{m.name}</p>
                          <span className="text-[10px] text-cream/30">{m.contact}</span>
                        </div>
                        <p className="text-cream/60 text-sm leading-relaxed">{m.body}</p>
                        <p className="text-cream/25 text-[10px] mt-2">
                          {new Date(m.createdAt).toLocaleString("fa-IR")}
                        </p>
                      </div>
                      <button
                        onClick={(e) => {
                          e.stopPropagation();
                          deleteMessage(m.id);
                        }}
                        className="p-2 rounded-lg hover:bg-red-500/10 text-cream/30 hover:text-red-300 shrink-0"
                      >
                        <Trash2 size={14} />
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* GALLERY */}
          {tab === "gallery" && (
            <div className="space-y-6">
              <div className="flex items-center justify-between">
                <div>
                  <h1 className="text-2xl font-light text-cream">گالری</h1>
                  <p className="text-cream/40 text-sm mt-1">{gallery.length} تصویر</p>
                </div>
                <button
                  onClick={addGalleryItem}
                  className="flex items-center gap-2 rounded-xl bg-champagne text-matte-black px-4 py-2.5 text-sm font-medium"
                >
                  <Plus size={16} /> افزودن
                </button>
              </div>
              <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-3">
                {gallery.map((g) => (
                  <div key={g.id} className="relative aspect-square rounded-xl overflow-hidden group border border-white/5">
                    <img src={g.src} alt={g.alt} className="w-full h-full object-cover" />
                    <div className="absolute inset-0 bg-black/60 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center">
                      <button
                        onClick={() => deleteGalleryItem(g.id)}
                        className="p-3 rounded-full bg-red-500/80 text-white hover:bg-red-500"
                      >
                        <Trash2 size={16} />
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* SETTINGS */}
          {tab === "settings" && (
            <div className="space-y-10 max-w-3xl">
              <div>
                <h1 className="text-2xl font-light text-cream">تنظیمات سایت</h1>
                <p className="text-cream/40 text-sm mt-1">همه چیز از اینجا روی سایت اصلی اعمال می‌شود</p>
              </div>

              {/* Brand + contact */}
              <form
                onSubmit={(e) => {
                  e.preventDefault();
                  persistSettings(settings);
                  showToast("تنظیمات ذخیره و روی سایت اعمال شد");
                }}
                className="rounded-2xl border border-white/6 bg-white/[0.03] p-6 space-y-5"
              >
                <h3 className="text-cream text-sm flex items-center gap-2">
                  <Settings size={16} className="text-champagne" /> برند و تماس
                </h3>
                <div className="grid sm:grid-cols-2 gap-4">
                  {(
                    [
                      ["brandName", "نام برند"],
                      ["tagline", "شعار سایت"],
                      ["phone", "تلفن"],
                      ["whatsapp", "واتساپ (با کد کشور، مثل 98912...)"],
                      ["instagram", "اینستاگرام (بدون @)"],
                    ] as const
                  ).map(([key, label]) => (
                    <div key={key} className={key === "tagline" ? "sm:col-span-2" : ""}>
                      <label className="block text-[11px] text-cream/40 mb-1.5">{label}</label>
                      <input
                        value={settings[key]}
                        onChange={(e) => setSettings({ ...settings, [key]: e.target.value })}
                        className="w-full bg-black/40 border border-white/10 rounded-xl px-4 py-2.5 text-sm text-cream focus:outline-none focus:border-champagne/40"
                      />
                    </div>
                  ))}
                </div>
                <div>
                  <label className="block text-[11px] text-cream/40 mb-1.5">آدرس فروشگاه / کارگاه</label>
                  <textarea
                    value={settings.address}
                    onChange={(e) => setSettings({ ...settings, address: e.target.value })}
                    rows={2}
                    className="w-full bg-black/40 border border-white/10 rounded-xl px-4 py-2.5 text-sm text-cream focus:outline-none focus:border-champagne/40 resize-none"
                  />
                </div>
                <label className="flex items-center gap-3 text-sm text-cream/70 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={settings.showPrices}
                    onChange={(e) => setSettings({ ...settings, showPrices: e.target.checked })}
                    className="accent-[#c9a962] w-4 h-4"
                  />
                  نمایش قیمت محصولات در سایت
                </label>
                <button type="submit" className="flex items-center gap-2 rounded-xl bg-champagne text-matte-black px-5 py-2.5 text-sm font-medium">
                  <Save size={15} /> ذخیره برند و تماس
                </button>
              </form>

              {/* Map / location */}
              <form
                onSubmit={(e) => {
                  e.preventDefault();
                  persistSettings(settings);
                  showToast("موقعیت نقشه ذخیره شد");
                }}
                className="rounded-2xl border border-white/6 bg-white/[0.03] p-6 space-y-5"
              >
                <h3 className="text-cream text-sm flex items-center gap-2">
                  <Image size={16} className="text-champagne" /> آدرس روی نقشه (مثل گوگل مپ)
                </h3>
                <p className="text-xs text-cream/40 leading-relaxed">
                  مختصات را از گوگل مپ کپی کنید: روی نقطه راست‌کلیک ← مختصات. یا لینک مستقیم گوگل مپ را بچسبانید.
                </p>
                <div className="grid sm:grid-cols-3 gap-4">
                  <div>
                    <label className="block text-[11px] text-cream/40 mb-1.5">عرض جغرافیایی (Lat)</label>
                    <input
                      value={settings.mapLat}
                      onChange={(e) => setSettings({ ...settings, mapLat: e.target.value })}
                      className="w-full bg-black/40 border border-white/10 rounded-xl px-4 py-2.5 text-sm text-cream focus:outline-none focus:border-champagne/40"
                      placeholder="35.7219"
                      dir="ltr"
                    />
                  </div>
                  <div>
                    <label className="block text-[11px] text-cream/40 mb-1.5">طول جغرافیایی (Lng)</label>
                    <input
                      value={settings.mapLng}
                      onChange={(e) => setSettings({ ...settings, mapLng: e.target.value })}
                      className="w-full bg-black/40 border border-white/10 rounded-xl px-4 py-2.5 text-sm text-cream focus:outline-none focus:border-champagne/40"
                      placeholder="51.4056"
                      dir="ltr"
                    />
                  </div>
                  <div>
                    <label className="block text-[11px] text-cream/40 mb-1.5">زوم (۱–۲۰)</label>
                    <input
                      value={settings.mapZoom}
                      onChange={(e) => setSettings({ ...settings, mapZoom: e.target.value })}
                      className="w-full bg-black/40 border border-white/10 rounded-xl px-4 py-2.5 text-sm text-cream focus:outline-none focus:border-champagne/40"
                      placeholder="15"
                      dir="ltr"
                    />
                  </div>
                </div>
                <div>
                  <label className="block text-[11px] text-cream/40 mb-1.5">لینک مستقیم گوگل مپ (اختیاری)</label>
                  <input
                    value={settings.mapLink}
                    onChange={(e) => setSettings({ ...settings, mapLink: e.target.value })}
                    className="w-full bg-black/40 border border-white/10 rounded-xl px-4 py-2.5 text-sm text-cream focus:outline-none focus:border-champagne/40"
                    placeholder="https://maps.google.com/..."
                    dir="ltr"
                  />
                </div>
                <div className="rounded-xl overflow-hidden border border-white/10 aspect-video bg-black/40">
                  <iframe
                    title="پیش‌نمایش نقشه"
                    src={buildMapEmbedUrl(settings)}
                    className="w-full h-full border-0"
                    loading="lazy"
                  />
                </div>
                <a
                  href={buildMapLink(settings)}
                  target="_blank"
                  rel="noreferrer"
                  className="text-xs text-champagne/80 hover:text-champagne"
                >
                  باز کردن در گوگل مپ ↗
                </a>
                <button type="submit" className="flex items-center gap-2 rounded-xl bg-champagne text-matte-black px-5 py-2.5 text-sm font-medium">
                  <Save size={15} /> ذخیره نقشه
                </button>
              </form>

              {/* Content / images */}
              <form
                onSubmit={(e) => {
                  e.preventDefault();
                  persistSettings(settings);
                  showToast("محتوای صفحات ذخیره شد");
                }}
                className="rounded-2xl border border-white/6 bg-white/[0.03] p-6 space-y-5"
              >
                <h3 className="text-cream text-sm">محتوای صفحه اصلی و درباره ما</h3>
                {(
                  [
                    ["heroImage", "تصویر هیرو (URL)"],
                    ["aboutImage", "تصویر درباره ما (URL)"],
                    ["aboutTitle", "عنوان درباره ما"],
                    ["ctaTitle", "عنوان بخش دعوت به اقدام"],
                    ["ctaText", "متن بخش دعوت به اقدام"],
                  ] as const
                ).map(([key, label]) => (
                  <div key={key}>
                    <label className="block text-[11px] text-cream/40 mb-1.5">{label}</label>
                    <input
                      value={settings[key]}
                      onChange={(e) => setSettings({ ...settings, [key]: e.target.value })}
                      className="w-full bg-black/40 border border-white/10 rounded-xl px-4 py-2.5 text-sm text-cream focus:outline-none focus:border-champagne/40"
                      dir={key.includes("Image") ? "ltr" : undefined}
                    />
                  </div>
                ))}
                <div>
                  <label className="block text-[11px] text-cream/40 mb-1.5">متن کامل درباره ما (پاراگراف‌ها با خط خالی جدا شوند)</label>
                  <textarea
                    value={settings.aboutText}
                    onChange={(e) => setSettings({ ...settings, aboutText: e.target.value })}
                    rows={6}
                    className="w-full bg-black/40 border border-white/10 rounded-xl px-4 py-2.5 text-sm text-cream focus:outline-none focus:border-champagne/40 resize-none"
                  />
                </div>
                <button type="submit" className="flex items-center gap-2 rounded-xl bg-champagne text-matte-black px-5 py-2.5 text-sm font-medium">
                  <Save size={15} /> ذخیره محتوا
                </button>
              </form>

              {/* Testimonials management */}
              <div className="rounded-2xl border border-white/6 bg-white/[0.03] p-6 space-y-4">
                <div className="flex items-center justify-between gap-3">
                  <h3 className="text-cream text-sm">نظرات مشتریان (نمایش در سایت)</h3>
                  <button
                    type="button"
                    onClick={() => {
                      const item: TestimonialItem = {
                        id: crypto.randomUUID(),
                        name: "نام مشتری",
                        role: "نقش / مناسبت",
                        text: "متن نظر...",
                      };
                      persistTestimonials([item, ...testimonials]);
                      showToast("نظر جدید اضافه شد — ویرایش کنید");
                    }}
                    className="text-xs flex items-center gap-1.5 text-champagne hover:text-champagne-light"
                  >
                    <Plus size={14} /> افزودن
                  </button>
                </div>
                {testimonials.map((t) => (
                  <div key={t.id} className="border border-white/8 rounded-xl p-4 space-y-2">
                    <div className="grid sm:grid-cols-2 gap-2">
                      <input
                        value={t.name}
                        onChange={(e) =>
                          persistTestimonials(
                            testimonials.map((x) => (x.id === t.id ? { ...x, name: e.target.value } : x))
                          )
                        }
                        className="bg-black/40 border border-white/10 rounded-lg px-3 py-2 text-sm text-cream"
                        placeholder="نام"
                      />
                      <input
                        value={t.role}
                        onChange={(e) =>
                          persistTestimonials(
                            testimonials.map((x) => (x.id === t.id ? { ...x, role: e.target.value } : x))
                          )
                        }
                        className="bg-black/40 border border-white/10 rounded-lg px-3 py-2 text-sm text-cream"
                        placeholder="نقش"
                      />
                    </div>
                    <textarea
                      value={t.text}
                      onChange={(e) =>
                        persistTestimonials(
                          testimonials.map((x) => (x.id === t.id ? { ...x, text: e.target.value } : x))
                        )
                      }
                      rows={2}
                      className="w-full bg-black/40 border border-white/10 rounded-lg px-3 py-2 text-sm text-cream resize-none"
                    />
                    <button
                      type="button"
                      onClick={() => {
                        if (confirm("حذف این نظر؟")) {
                          persistTestimonials(testimonials.filter((x) => x.id !== t.id));
                          showToast("حذف شد");
                        }
                      }}
                      className="text-xs text-red-400/80 hover:text-red-300"
                    >
                      حذف
                    </button>
                  </div>
                ))}
                {testimonials.length === 0 && (
                  <p className="text-cream/30 text-sm">نظری ثبت نشده</p>
                )}
              </div>

              {/* Password */}
              <form
                onSubmit={handleChangePassword}
                className="rounded-2xl border border-white/6 bg-white/[0.03] p-6 space-y-4"
              >
                <h3 className="text-cream text-sm flex items-center gap-2 mb-2">
                  <KeyRound size={16} className="text-champagne" /> تغییر رمز عبور
                </h3>
                {[
                  { key: "current" as const, label: "رمز فعلی" },
                  { key: "next" as const, label: "رمز جدید (حداقل ۸ کاراکتر)" },
                  { key: "confirm" as const, label: "تکرار رمز جدید" },
                ].map((f) => (
                  <div key={f.key}>
                    <label className="block text-[11px] text-cream/40 mb-1.5">{f.label}</label>
                    <div className="relative">
                      <input
                        type={showPwd ? "text" : "password"}
                        value={pwdForm[f.key]}
                        onChange={(e) => setPwdForm({ ...pwdForm, [f.key]: e.target.value })}
                        className="w-full bg-black/40 border border-white/10 rounded-xl px-4 py-2.5 pl-11 text-sm text-cream focus:outline-none focus:border-champagne/40"
                        required
                        minLength={f.key === "current" ? 6 : 8}
                      />
                      {f.key === "confirm" && (
                        <button
                          type="button"
                          onClick={() => setShowPwd(!showPwd)}
                          className="absolute left-3 top-1/2 -translate-y-1/2 text-cream/30 hover:text-champagne"
                        >
                          {showPwd ? <EyeOff size={16} /> : <Eye size={16} />}
                        </button>
                      )}
                    </div>
                  </div>
                ))}
                {pwdMsg && (
                  <p className={`text-xs ${pwdMsg.includes("موفق") ? "text-emerald-400" : "text-red-400"}`}>
                    {pwdMsg}
                  </p>
                )}
                <button type="submit" className="flex items-center gap-2 rounded-xl border border-champagne/50 text-champagne px-5 py-2.5 text-sm hover:bg-champagne/10 transition-colors">
                  <KeyRound size={15} /> تغییر رمز
                </button>
              </form>
            </div>
          )}
        </div>
      </div>


      {/* Order price/note modal */}
      <AnimatePresence>
        {editingOrder && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-end sm:items-center justify-center p-0 sm:p-6"
            onClick={() => setEditingOrder(null)}
          >
            <motion.form
              initial={{ y: 40, opacity: 0 }}
              animate={{ y: 0, opacity: 1 }}
              exit={{ y: 40, opacity: 0 }}
              onClick={(e) => e.stopPropagation()}
              onSubmit={saveOrderDetails}
              className="w-full max-w-md max-h-[90vh] overflow-y-auto rounded-t-3xl sm:rounded-2xl bg-[#141414] border border-white/10 p-6 space-y-4"
            >
              <div className="flex items-center justify-between">
                <div>
                  <h2 className="text-lg text-cream font-light">قیمت و توضیح برای مشتری</h2>
                  <p className="text-xs text-champagne/70 mt-1 tracking-wider" dir="ltr">
                    {editingOrder.trackingCode}
                  </p>
                </div>
                <button type="button" onClick={() => setEditingOrder(null)} className="p-2 text-cream/40 hover:text-cream">
                  <X size={20} />
                </button>
              </div>

              <div>
                <label className="text-[11px] text-cream/40 mb-1 block">وضعیت</label>
                <select
                  value={editingOrder.status}
                  onChange={(e) =>
                    setEditingOrder({ ...editingOrder, status: e.target.value as OrderStatus })
                  }
                  className="w-full bg-black/40 border border-white/10 rounded-xl px-4 py-2.5 text-sm text-cream"
                >
                  {(Object.keys(statusLabel) as OrderStatus[]).map((s) => (
                    <option key={s} value={s}>{statusLabel[s]}</option>
                  ))}
                </select>
              </div>

              <div>
                <label className="text-[11px] text-cream/40 mb-1 block">قیمت اعلامی (تومان)</label>
                <input
                  type="number"
                  value={editingOrder.quotedPrice ?? ""}
                  onChange={(e) =>
                    setEditingOrder({
                      ...editingOrder,
                      quotedPrice: e.target.value ? Number(e.target.value) : null,
                    })
                  }
                  placeholder="مثلاً 25000000"
                  className="w-full bg-black/40 border border-white/10 rounded-xl px-4 py-2.5 text-sm text-cream focus:outline-none focus:border-champagne/40"
                />
                <p className="text-[10px] text-cream/30 mt-1">خالی بگذارید تا به مشتری «هنوز اعلام نشده» نشان داده شود</p>
              </div>

              <div>
                <label className="text-[11px] text-cream/40 mb-1 block">زمان تقریبی آماده‌سازی</label>
                <input
                  value={editingOrder.estimatedReady || ""}
                  onChange={(e) =>
                    setEditingOrder({ ...editingOrder, estimatedReady: e.target.value })
                  }
                  placeholder="مثلاً ۳ تا ۴ هفته"
                  className="w-full bg-black/40 border border-white/10 rounded-xl px-4 py-2.5 text-sm text-cream focus:outline-none focus:border-champagne/40"
                />
              </div>

              <div>
                <label className="text-[11px] text-cream/40 mb-1 block">توضیح برای مشتری (در صفحه پیگیری دیده می‌شود)</label>
                <textarea
                  value={editingOrder.adminNote || ""}
                  onChange={(e) =>
                    setEditingOrder({ ...editingOrder, adminNote: e.target.value })
                  }
                  rows={4}
                  placeholder="مثلاً: طرح تایید شد، پارچه رزرو شده..."
                  className="w-full bg-black/40 border border-white/10 rounded-xl px-4 py-2.5 text-sm text-cream focus:outline-none focus:border-champagne/40 resize-none"
                />
              </div>

              <div className="flex gap-3 pt-1">
                <button type="submit" className="flex-1 rounded-xl bg-champagne text-matte-black py-3 text-sm font-medium flex items-center justify-center gap-2">
                  <Check size={16} /> ذخیره و نمایش به مشتری
                </button>
                <button
                  type="button"
                  onClick={() => setEditingOrder(null)}
                  className="px-5 rounded-xl border border-white/15 text-cream/60 text-sm"
                >
                  انصراف
                </button>
              </div>
            </motion.form>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Product edit modal */}
      <AnimatePresence>
        {editing && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-end sm:items-center justify-center p-0 sm:p-6"
            onClick={() => setEditing(null)}
          >
            <motion.form
              initial={{ y: 40, opacity: 0 }}
              animate={{ y: 0, opacity: 1 }}
              exit={{ y: 40, opacity: 0 }}
              onClick={(e) => e.stopPropagation()}
              onSubmit={saveProduct}
              className="w-full max-w-lg max-h-[90vh] overflow-y-auto rounded-t-3xl sm:rounded-2xl bg-[#141414] border border-white/10 p-6 space-y-4"
            >
              <div className="flex items-center justify-between mb-2">
                <h2 className="text-lg text-cream font-light">
                  {products.some((p) => p.id === editing.id) ? "ویرایش محصول" : "محصول جدید"}
                </h2>
                <button type="button" onClick={() => setEditing(null)} className="p-2 text-cream/40 hover:text-cream">
                  <X size={20} />
                </button>
              </div>

              <div>
                <label className="text-[11px] text-cream/40 mb-1 block">نام</label>
                <input
                  value={editing.name}
                  onChange={(e) => setEditing({ ...editing, name: e.target.value })}
                  className="w-full bg-black/40 border border-white/10 rounded-xl px-4 py-2.5 text-sm text-cream focus:outline-none focus:border-champagne/40"
                  required
                />
              </div>
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="text-[11px] text-cream/40 mb-1 block">دسته</label>
                  <select
                    value={editing.category}
                    onChange={(e) => setEditing({ ...editing, category: e.target.value as Category })}
                    className="w-full bg-black/40 border border-white/10 rounded-xl px-4 py-2.5 text-sm text-cream focus:outline-none"
                  >
                    {(Object.keys(categoryLabels) as Category[]).map((c) => (
                      <option key={c} value={c}>{categoryLabels[c]}</option>
                    ))}
                  </select>
                </div>
                <div>
                  <label className="text-[11px] text-cream/40 mb-1 block">قیمت (تومان)</label>
                  <input
                    type="number"
                    value={editing.price ?? ""}
                    onChange={(e) =>
                      setEditing({
                        ...editing,
                        price: e.target.value ? Number(e.target.value) : null,
                      })
                    }
                    className="w-full bg-black/40 border border-white/10 rounded-xl px-4 py-2.5 text-sm text-cream focus:outline-none focus:border-champagne/40"
                  />
                </div>
              </div>
              <div>
                <label className="text-[11px] text-cream/40 mb-1 block">جنس پارچه</label>
                <input
                  value={editing.fabric}
                  onChange={(e) => setEditing({ ...editing, fabric: e.target.value })}
                  className="w-full bg-black/40 border border-white/10 rounded-xl px-4 py-2.5 text-sm text-cream focus:outline-none focus:border-champagne/40"
                />
              </div>
              <div>
                <label className="text-[11px] text-cream/40 mb-1 block">توضیحات</label>
                <textarea
                  value={editing.description}
                  onChange={(e) => setEditing({ ...editing, description: e.target.value })}
                  rows={3}
                  className="w-full bg-black/40 border border-white/10 rounded-xl px-4 py-2.5 text-sm text-cream focus:outline-none focus:border-champagne/40 resize-none"
                />
              </div>
              <div>
                <label className="text-[11px] text-cream/40 mb-1 block">رنگ‌ها (با ویرگول)</label>
                <input
                  value={editing.colors.join("، ")}
                  onChange={(e) =>
                    setEditing({
                      ...editing,
                      colors: e.target.value.split(/[،,]/).map((s) => s.trim()).filter(Boolean),
                    })
                  }
                  className="w-full bg-black/40 border border-white/10 rounded-xl px-4 py-2.5 text-sm text-cream focus:outline-none focus:border-champagne/40"
                />
              </div>
              <div>
                <label className="text-[11px] text-cream/40 mb-1 block">سایزها (با ویرگول)</label>
                <input
                  value={editing.sizes.join("، ")}
                  onChange={(e) =>
                    setEditing({
                      ...editing,
                      sizes: e.target.value.split(/[،,]/).map((s) => s.trim()).filter(Boolean),
                    })
                  }
                  className="w-full bg-black/40 border border-white/10 rounded-xl px-4 py-2.5 text-sm text-cream focus:outline-none focus:border-champagne/40"
                />
              </div>
              <div>
                <label className="text-[11px] text-cream/40 mb-1 block">آدرس تصویر اصلی</label>
                <input
                  value={editing.images[0] || ""}
                  onChange={(e) => setEditing({ ...editing, images: [e.target.value, ...editing.images.slice(1)] })}
                  className="w-full bg-black/40 border border-white/10 rounded-xl px-4 py-2.5 text-sm text-cream focus:outline-none focus:border-champagne/40"
                  placeholder="https://..."
                />
              </div>
              <div className="flex gap-4 text-sm text-cream/60">
                <label className="flex items-center gap-2 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={editing.showPrice}
                    onChange={(e) => setEditing({ ...editing, showPrice: e.target.checked })}
                    className="accent-[#d4af37]"
                  />
                  نمایش قیمت
                </label>
                <label className="flex items-center gap-2 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={!!editing.featured}
                    onChange={(e) => setEditing({ ...editing, featured: e.target.checked })}
                    className="accent-[#d4af37]"
                  />
                  محصول ویژه
                </label>
              </div>
              <div className="flex gap-3 pt-2">
                <button
                  type="submit"
                  className="flex-1 flex items-center justify-center gap-2 rounded-xl bg-champagne text-matte-black py-3 text-sm font-medium"
                >
                  <Check size={16} /> ذخیره
                </button>
                <button
                  type="button"
                  onClick={() => setEditing(null)}
                  className="px-5 rounded-xl border border-white/15 text-cream/60 text-sm hover:bg-white/5"
                >
                  انصراف
                </button>
              </div>
            </motion.form>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Toast */}
      <AnimatePresence>
        {toast && (
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: 20 }}
            className="fixed bottom-8 left-1/2 -translate-x-1/2 z-[60] bg-champagne text-matte-black text-sm px-5 py-3 rounded-full shadow-lg shadow-champagne/20 flex items-center gap-2"
          >
            <Check size={16} />
            {toast}
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
