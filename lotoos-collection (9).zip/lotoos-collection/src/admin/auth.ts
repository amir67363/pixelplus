/**
 * لایه امنیت پنل ادمین
 * رمز قابل تغییر از داخل پنل ذخیره می‌شود در localStorage (هش‌شده)
 */

const AUTH_KEY = "lotoos_admin_session";
const AUTH_TS_KEY = "lotoos_admin_ts";
const PWD_HASH_KEY = "lotoos_admin_pwd_hash";
const ATTEMPTS_KEY = "lotoos_admin_attempts";
const LOCK_UNTIL_KEY = "lotoos_admin_lock";

const FALLBACK_PASSWORD = "Lotoos@Admin2026";
const SESSION_TTL = 4 * 60 * 60 * 1000;
const MAX_ATTEMPTS = 5;
const LOCK_MS = 15 * 60 * 1000;

async function hashPassword(plain: string): Promise<string> {
  const enc = new TextEncoder();
  const data = enc.encode(plain + "|lotoos-salt-v1");
  const buf = await crypto.subtle.digest("SHA-256", data);
  return Array.from(new Uint8Array(buf))
    .map((b) => b.toString(16).padStart(2, "0"))
    .join("");
}

async function getStoredHash(): Promise<string> {
  try {
    const stored = localStorage.getItem(PWD_HASH_KEY);
    if (stored) return stored;
  } catch { /* ignore */ }
  return hashPassword(FALLBACK_PASSWORD);
}

export function isLocked(): { locked: boolean; remainingMs: number } {
  try {
    const until = Number(localStorage.getItem(LOCK_UNTIL_KEY) || 0);
    const now = Date.now();
    if (until > now) return { locked: true, remainingMs: until - now };
    return { locked: false, remainingMs: 0 };
  } catch {
    return { locked: false, remainingMs: 0 };
  }
}

function recordFailedAttempt(): number {
  try {
    const raw = localStorage.getItem(ATTEMPTS_KEY);
    const data = raw ? JSON.parse(raw) : { count: 0 };
    data.count += 1;
    localStorage.setItem(ATTEMPTS_KEY, JSON.stringify(data));
    if (data.count >= MAX_ATTEMPTS) {
      localStorage.setItem(LOCK_UNTIL_KEY, String(Date.now() + LOCK_MS));
      localStorage.removeItem(ATTEMPTS_KEY);
      return 0;
    }
    return MAX_ATTEMPTS - data.count;
  } catch {
    return MAX_ATTEMPTS;
  }
}

function clearAttempts(): void {
  try {
    localStorage.removeItem(ATTEMPTS_KEY);
    localStorage.removeItem(LOCK_UNTIL_KEY);
  } catch { /* ignore */ }
}

export async function login(password: string): Promise<{ ok: boolean; error?: string }> {
  const lock = isLocked();
  if (lock.locked) {
    const mins = Math.ceil(lock.remainingMs / 60000);
    return { ok: false, error: `پنل موقتاً قفل است. حدود ${mins} دقیقه دیگر.` };
  }
  if (!password || password.length < 6) {
    const left = recordFailedAttempt();
    return { ok: false, error: left > 0 ? `رمز نامعتبر. ${left} تلاش باقی.` : "پنل قفل شد." };
  }

  const expected = await getStoredHash();
  const given = await hashPassword(password);
  if (given !== expected) {
    const left = recordFailedAttempt();
    return {
      ok: false,
      error: left > 0 ? `رمز اشتباه. ${left} تلاش باقی مانده.` : "رمز اشتباه. پنل قفل شد.",
    };
  }

  clearAttempts();
  const token = await hashPassword(password + "|" + Date.now());
  try {
    sessionStorage.setItem(AUTH_KEY, token);
    sessionStorage.setItem(AUTH_TS_KEY, String(Date.now()));
  } catch {
    return { ok: false, error: "خطا در ذخیره نشست." };
  }
  return { ok: true };
}

export function logout(): void {
  try {
    sessionStorage.removeItem(AUTH_KEY);
    sessionStorage.removeItem(AUTH_TS_KEY);
  } catch { /* ignore */ }
}

export function isAuthenticated(): boolean {
  try {
    const token = sessionStorage.getItem(AUTH_KEY);
    const ts = Number(sessionStorage.getItem(AUTH_TS_KEY) || 0);
    if (!token || !ts) return false;
    if (Date.now() - ts > SESSION_TTL) {
      logout();
      return false;
    }
    return true;
  } catch {
    return false;
  }
}

export function touchSession(): void {
  if (!isAuthenticated()) return;
  try {
    sessionStorage.setItem(AUTH_TS_KEY, String(Date.now()));
  } catch { /* ignore */ }
}

/** تغییر رمز — نیاز به رمز فعلی */
export async function changePassword(
  current: string,
  next: string
): Promise<{ ok: boolean; error?: string }> {
  if (!next || next.length < 8) {
    return { ok: false, error: "رمز جدید حداقل ۸ کاراکتر باشد." };
  }
  if (next === current) {
    return { ok: false, error: "رمز جدید با رمز فعلی یکی است." };
  }
  const expected = await getStoredHash();
  const given = await hashPassword(current);
  if (given !== expected) {
    return { ok: false, error: "رمز فعلی اشتباه است." };
  }
  const newHash = await hashPassword(next);
  try {
    localStorage.setItem(PWD_HASH_KEY, newHash);
  } catch {
    return { ok: false, error: "ذخیره رمز جدید ممکن نشد." };
  }
  // تمدید نشست
  touchSession();
  return { ok: true };
}

export function hasCustomPassword(): boolean {
  try {
    return Boolean(localStorage.getItem(PWD_HASH_KEY));
  } catch {
    return false;
  }
}
