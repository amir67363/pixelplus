import { products as seedProducts, type Product, type Category } from "../data/products";

export type OrderStatus = "new" | "reviewing" | "in_progress" | "done" | "cancelled";

export interface CustomOrder {
  id: string;
  /** کد پیگیری کوتاه برای مشتری */
  trackingCode: string;
  name: string;
  phone: string;
  type: string;
  size: string;
  color: string;
  notes: string;
  imageName?: string;
  status: OrderStatus;
  createdAt: string;
  updatedAt?: string;
  /** قیمت اعلام‌شده به مشتری (تومان) — null یعنی هنوز اعلام نشده */
  quotedPrice: number | null;
  /** توضیحات ادمین برای مشتری (قابل مشاهده در صفحه پیگیری) */
  adminNote: string;
  /** تاریخ تقریبی آماده‌سازی (متن آزاد) */
  estimatedReady: string;
}

export interface CustomerMessage {
  id: string;
  name: string;
  contact: string;
  body: string;
  read: boolean;
  createdAt: string;
}

export interface GalleryItem {
  id: string;
  src: string;
  alt: string;
  type: "image" | "video";
  createdAt: string;
}

export interface TestimonialItem {
  id: string;
  name: string;
  role: string;
  text: string;
}

export interface SiteSettings {
  brandName: string;
  tagline: string;
  phone: string;
  whatsapp: string;
  instagram: string;
  address: string;
  /** مختصات برای نقشه — مثال: 35.6892,51.3890 */
  mapLat: string;
  mapLng: string;
  /** زوم نقشه گوگل (1-20) */
  mapZoom: string;
  /** لینک مستقیم گوگل مپ (اختیاری؛ اگر خالی باشد از lat/lng ساخته می‌شود) */
  mapLink: string;
  showPrices: boolean;
  heroImage: string;
  aboutImage: string;
  aboutTitle: string;
  aboutText: string;
  ctaTitle: string;
  ctaText: string;
}

const KEYS = {
  products: "lotoos_products",
  orders: "lotoos_orders",
  messages: "lotoos_messages",
  gallery: "lotoos_gallery",
  settings: "lotoos_settings",
  testimonials: "lotoos_testimonials",
};

function load<T>(key: string, fallback: T): T {
  try {
    const raw = localStorage.getItem(key);
    if (raw) return JSON.parse(raw) as T;
  } catch { /* ignore */ }
  return fallback;
}

function save<T>(key: string, data: T): void {
  try {
    localStorage.setItem(key, JSON.stringify(data));
  } catch { /* ignore */ }
}

export const defaultSettings: SiteSettings = {
  brandName: "Lotoos Collection",
  tagline: "آغازی برای خلق استایلی منحصر به فرد",
  phone: "09121234567",
  whatsapp: "989121234567",
  instagram: "lotoos.collection",
  address: "تهران، خیابان ولیعصر، کارگاه اختصاصی لوتوس",
  mapLat: "35.7219",
  mapLng: "51.4056",
  mapZoom: "15",
  mapLink: "",
  showPrices: true,
  heroImage: "https://images.unsplash.com/photo-1515372039744-b8f02a3ae446?w=1920&q=85",
  aboutImage: "https://images.unsplash.com/photo-1558769132-cb1aea458c5e?w=900&q=80",
  aboutTitle: "داستان لوتوس",
  aboutText:
    "لوتوس از علاقه به ظرافت، پارچه‌های اصیل و دوخت دستی متولد شد. هر لباس در آتللیه ما با دقت ساعت‌ها طراحی و دوخته می‌شود تا حس یک قطعه منحصربه‌فرد را به شما بدهد.\n\nما معتقدیم لباس لوکس فقط ظاهر نیست؛ لمس پارچه، حرکت روی بدن و جزئیاتی که فقط از نزدیک دیده می‌شوند، هویت واقعی یک برند هستند.\n\nکیفیت، ظرافت و کار دست — سه اصل غیرقابل مذاکره لوتوس.",
  ctaTitle: "لباس رویایی‌ات را بساز",
  ctaText: "از ایده تا دوخت نهایی، کنار شماییم. یک گفت‌وگوی ساده کافی است تا شروع کنیم.",
};

function makeTrackingCode(): string {
  const chars = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789";
  let s = "LT-";
  for (let i = 0; i < 6; i++) s += chars[Math.floor(Math.random() * chars.length)];
  return s;
}

const seedOrders: CustomOrder[] = [
  {
    id: "o1",
    trackingCode: "LT-SA7K2M",
    name: "سارا محمدی",
    phone: "09121234567",
    type: "لباس عروس",
    size: "۳۸",
    color: "سفید عاجی",
    notes: "می‌خوام دامن حجیم و آستین بلند باشه، مروارید هم داشته باشه.",
    status: "reviewing",
    createdAt: new Date(Date.now() - 86400000 * 2).toISOString(),
    updatedAt: new Date(Date.now() - 3600000 * 5).toISOString(),
    quotedPrice: 42000000,
    adminNote: "طرح اولیه تایید شد. پارچه ساتن دوشس رزرو شده. لطفاً برای اندازه‌گیری نهایی هماهنگ کنید.",
    estimatedReady: "حدود ۴ تا ۵ هفته",
  },
  {
    id: "o2",
    trackingCode: "LT-N9P4QX",
    name: "نیلوفر کریمی",
    phone: "09351112233",
    type: "لباس مجلسی",
    size: "۴۰",
    color: "شامپاینی",
    notes: "برای جشن سالگرد ازدواج، مدل بسته و شیک.",
    status: "new",
    createdAt: new Date(Date.now() - 86400000).toISOString(),
    quotedPrice: null,
    adminNote: "",
    estimatedReady: "",
  },
];

const seedMessages: CustomerMessage[] = [
  {
    id: "m1",
    name: "مریم ر.",
    contact: "instagram",
    body: "سلام، سایز ۴۲ هم برای لباس مشکی مات موجوده؟",
    read: false,
    createdAt: new Date(Date.now() - 3600000 * 5).toISOString(),
  },
  {
    id: "m2",
    name: "آیدا",
    contact: "whatsapp",
    body: "زمان دوخت لباس عقد حدوداً چقدره؟",
    read: true,
    createdAt: new Date(Date.now() - 86400000 * 3).toISOString(),
  },
];

const seedGallery: GalleryItem[] = [
  {
    id: "g1",
    src: "https://images.unsplash.com/photo-1595777457583-95e059d581b8?w=600&q=80",
    alt: "لباس مجلسی",
    type: "image",
    createdAt: new Date().toISOString(),
  },
  {
    id: "g2",
    src: "https://images.unsplash.com/photo-1515372039744-b8f02a3ae446?w=600&q=80",
    alt: "لباس عروس",
    type: "image",
    createdAt: new Date().toISOString(),
  },
  {
    id: "g3",
    src: "https://images.unsplash.com/photo-1558171813-4c088753af8f?w=600&q=80",
    alt: "جزئیات دوخت",
    type: "image",
    createdAt: new Date().toISOString(),
  },
];

const seedTestimonials: TestimonialItem[] = [
  {
    id: "t1",
    name: "سارا م.",
    role: "عروس ۱۴۰۳",
    text: "لباس عروسم فراتر از تصور بود. هر دوخت و هر مروارید با عشق کار شده. احساس می‌کردم یک قطعه هنری پوشیده‌ام.",
  },
  {
    id: "t2",
    name: "نیلوفر ک.",
    role: "مشتری مجلسی",
    text: "کیفیت پارچه و ظرافت دوخت بی‌نظیر است. برای اولین بار لباسی داشتم که دقیقاً اندازه بدنم بود و حرکت می‌کرد.",
  },
  {
    id: "t3",
    name: "مریم ر.",
    role: "سفارش اختصاصی",
    text: "از ایده خام تا لباس نهایی، همراهی تیم لوتوس فوق‌العاده بود. حس برند اروپایی با روح ایرانی.",
  },
];

/** ادغام تنظیمات ذخیره‌شده با پیش‌فرض‌ها تا فیلدهای جدید از بین نروند */
function mergeSettings(stored: Partial<SiteSettings> | null): SiteSettings {
  return { ...defaultSettings, ...(stored || {}) };
}

export const store = {
  getProducts: (): Product[] => load(KEYS.products, seedProducts),
  setProducts: (p: Product[]) => save(KEYS.products, p),

  getOrders: (): CustomOrder[] => {
    const list = load(KEYS.orders, seedOrders);
    return list.map((o) => ({
      quotedPrice: null,
      adminNote: "",
      estimatedReady: "",
      trackingCode: o.trackingCode || makeTrackingCode(),
      ...o,
      trackingCode: o.trackingCode || makeTrackingCode(),
      quotedPrice: o.quotedPrice ?? null,
      adminNote: o.adminNote || "",
      estimatedReady: o.estimatedReady || "",
    }));
  },
  setOrders: (o: CustomOrder[]) => save(KEYS.orders, o),

  getMessages: (): CustomerMessage[] => load(KEYS.messages, seedMessages),
  setMessages: (m: CustomerMessage[]) => save(KEYS.messages, m),

  getGallery: (): GalleryItem[] => load(KEYS.gallery, seedGallery),
  setGallery: (g: GalleryItem[]) => save(KEYS.gallery, g),

  getTestimonials: (): TestimonialItem[] => load(KEYS.testimonials, seedTestimonials),
  setTestimonials: (t: TestimonialItem[]) => save(KEYS.testimonials, t),

  getSettings: (): SiteSettings => {
    try {
      const raw = localStorage.getItem(KEYS.settings);
      if (raw) return mergeSettings(JSON.parse(raw));
    } catch { /* ignore */ }
    return { ...defaultSettings };
  },
  setSettings: (s: SiteSettings) => save(KEYS.settings, s),
};

export function buildMapEmbedUrl(s: SiteSettings): string {
  const lat = s.mapLat || defaultSettings.mapLat;
  const lng = s.mapLng || defaultSettings.mapLng;
  const zoom = s.mapZoom || "15";
  // OpenStreetMap embed — بدون نیاز به API key گوگل
  return `https://www.openstreetmap.org/export/embed.html?bbox=${Number(lng) - 0.01}%2C${Number(lat) - 0.008}%2C${Number(lng) + 0.01}%2C${Number(lat) + 0.008}&layer=mapnik&marker=${lat}%2C${lng}`;
}

export function buildMapLink(s: SiteSettings): string {
  if (s.mapLink?.trim()) return s.mapLink.trim();
  const lat = s.mapLat || defaultSettings.mapLat;
  const lng = s.mapLng || defaultSettings.mapLng;
  return `https://www.google.com/maps?q=${lat},${lng}`;
}

export function findOrderByTracking(code: string): CustomOrder | null {
  const c = code.trim().toUpperCase();
  if (!c) return null;
  const orders = store.getOrders();
  return orders.find((o) => o.trackingCode.toUpperCase() === c) || null;
}

export function generateTrackingCode(): string {
  return makeTrackingCode();
}

export type { Product, Category };
export { categoryLabels } from "../data/products";
