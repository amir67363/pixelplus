import type { Transition, Variants } from "framer-motion";

/** ease لوکس نزدیک نمونه مرجع */
export const EASE: [number, number, number, number] = [0.16, 1, 0.3, 1];

export const RM =
  typeof window !== "undefined" &&
  window.matchMedia("(prefers-reduced-motion: reduce)").matches;

export const transition = (delay = 0, duration = 0.85): Transition =>
  RM
    ? { duration: 0.01 }
    : { duration, delay, ease: EASE };

export const fadeUp = (delay = 0, y = 28): Variants => ({
  hidden: RM ? { opacity: 1, y: 0 } : { opacity: 0, y },
  show: {
    opacity: 1,
    y: 0,
    transition: transition(delay),
  },
});

export const fadeIn = (delay = 0): Variants => ({
  hidden: RM ? { opacity: 1 } : { opacity: 0 },
  show: { opacity: 1, transition: transition(delay, 0.9) },
});

export const stagger = (staggerChildren = 0.08, delayChildren = 0.1): Variants => ({
  hidden: {},
  show: {
    transition: RM
      ? { duration: 0.01 }
      : { staggerChildren, delayChildren },
  },
});

export const scaleIn = (delay = 0): Variants => ({
  hidden: RM ? { opacity: 1, scale: 1 } : { opacity: 0, scale: 0.96 },
  show: {
    opacity: 1,
    scale: 1,
    transition: transition(delay, 0.7),
  },
});

export const viewportOnce = { once: true, margin: "-70px" as const };
