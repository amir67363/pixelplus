export type Category = "mjlsi" | "aroos" | "aghd" | "custom" | "new";

export interface Product {
  id: string;
  name: string;
  category: Category;
  description: string;
  longDescription?: string;
  fabric: string;
  colors: string[];
  sizes: string[];
  price: number | null;
  showPrice: boolean;
  images: string[];
  featured?: boolean;
  badge?: string;
  handmadeHours?: number;
  care?: string;
}

export const categoryLabels: Record<Category, string> = {
  mjlsi: "لباس مجلسی",
  aroos: "لباس عروس",
  aghd: "لباس عقد",
  custom: "طراحی اختصاصی",
  new: "جدیدترین‌ها",
};

export const products: Product[] = [
  {
    id: "1",
    name: "گان «شب مهتاب»",
    category: "mjlsi",
    description: "سیلوئت ماکسی با دکلتهٔ دراپه و درزهای دوخت دست؛ برای مجالسی که می‌خواهید بی‌هیاهو بدرخشید.",
    longDescription:
      "این گان از کرپ ابریشم ایتالیا با آستر ساتن دوخته شده. بالاتنه با دراپه‌های دقیق فرم می‌گیرد و دامن با حرکت آزاد جریان دارد. تمام درزهای نمایان با دوخت دست تکمیل شده‌اند.",
    fabric: "کرپ ابریشم ایتالیا با آستر ساتن",
    colors: ["مشکی", "زمردی", "شامپاینی"],
    sizes: ["۳۶", "۳۸", "۴۰", "۴۲", "۴۴"],
    price: 18900000,
    showPrice: true,
    images: [
      "https://images.unsplash.com/photo-1595777457583-95e059d581b8?w=1000&q=85",
      "https://images.unsplash.com/photo-1566174053879-31528523f8ae?w=1000&q=85",
      "https://images.unsplash.com/photo-1515372039744-b8f02a3ae446?w=1000&q=85",
    ],
    featured: true,
    badge: "جدید",
    handmadeHours: 40,
    care: "خشکشویی حرفه‌ای · اتو با دمای پایین",
  },
  {
    id: "2",
    name: "مجلسی «رویای طلایی»",
    category: "mjlsi",
    description: "بالاتنهٔ تمام‌کارشده و دامن چندلایه؛ بیش از ۱۲۰ ساعت کار دست آتلیه.",
    longDescription:
      "تور دوخته‌شده با پولک اتریشی، روی آستر ابریشمین. هر پولک با دست چیده شده. مناسب شب‌های خاص و عکاسی رسمی.",
    fabric: "تور دوخته‌شده با پولک اتریشی",
    colors: ["طلایی شامپاینی", "کرم"],
    sizes: ["۳۶", "۳۸", "۴۰", "۴۲", "۴۴", "۴۶"],
    price: 24500000,
    showPrice: true,
    images: [
      "https://images.unsplash.com/photo-1566174053879-31528523f8ae?w=1000&q=85",
      "https://images.unsplash.com/photo-1595777457583-95e059d581b8?w=1000&q=85",
    ],
    featured: true,
    badge: "کار دست",
    handmadeHours: 120,
    care: "خشکشویی · نگهداری افقی",
  },
  {
    id: "3",
    name: "عروس «لوتوس کلاسیک»",
    category: "aroos",
    description: "مدل امضای لوتوس؛ بالاتنهٔ کرستی، دنبالهٔ دو و نیم متری و دانتل فرانسوی.",
    longDescription:
      "دوشس ابریشم و دانتل فرانسوی. بالاتنه با استخوان‌بندی سبک، دنبالهٔ ۲٫۵ متری، و جای‌گذاری دانتل کاملاً با دست. قابل تنظیم در جلسات فیتینگ.",
    fabric: "دوشس ابریشم و دانتل فرانسوی",
    colors: ["سفید", "شیری"],
    sizes: ["۳۶", "۳۸", "۴۰", "۴۲", "۴۴", "۴۶"],
    price: 68000000,
    showPrice: true,
    images: [
      "https://images.unsplash.com/photo-1515372039744-b8f02a3ae446?w=1000&q=85",
      "https://images.unsplash.com/photo-1469334031218-e382a71b716b?w=1000&q=85",
    ],
    featured: true,
    badge: "امضای برند",
    handmadeHours: 200,
    care: "خشکشویی تخصصی لباس عروس",
  },
  {
    id: "4",
    name: "عروس مینیمال «آتره»",
    category: "aroos",
    description: "خطوط پاک و سیلوئت معماری‌گونه؛ برای عروس‌هایی که مینیمالیسم مدرن را دوست دارند.",
    fabric: "ساتن ابریشم سنگین",
    colors: ["شیری"],
    sizes: ["۳۶", "۳۸", "۴۰", "۴۲", "۴۴"],
    price: 42000000,
    showPrice: true,
    images: [
      "https://images.unsplash.com/photo-1469334031218-e382a71b716b?w=1000&q=85",
      "https://images.unsplash.com/photo-1515372039744-b8f02a3ae446?w=1000&q=85",
    ],
    featured: true,
    handmadeHours: 90,
  },
  {
    id: "5",
    name: "عقد «رز»",
    category: "aghd",
    description: "دامن کلوش و کار دست مروارید روی شانه؛ انتخابی رمانتیک برای مراسم عقد.",
    fabric: "تور ابریشمین با گلدوزی",
    colors: ["صورتی چرک", "کرم"],
    sizes: ["۳۶", "۳۸", "۴۰", "۴۲", "۴۴"],
    price: 21800000,
    showPrice: true,
    images: [
      "https://images.unsplash.com/photo-1558171813-4c088753af8f?w=1000&q=85",
      "https://images.unsplash.com/photo-1595777457583-95e059d581b8?w=1000&q=85",
    ],
    badge: "محبوب",
    handmadeHours: 55,
  },
  {
    id: "6",
    name: "مجلسی «دلآرام»",
    category: "mjlsi",
    description: "آستین بلند و سیلوئت فیت؛ مخملی که زیر نور سالن می‌درخشد.",
    fabric: "مخمل ابریشمی",
    colors: ["زرشکی", "سرمه‌ای", "مشکی"],
    sizes: ["۳۸", "۴۰", "۴۲", "۴۴", "۴۶", "۴۸"],
    price: 16400000,
    showPrice: true,
    images: [
      "https://images.unsplash.com/photo-1558769132-cb1aea458c5e?w=1000&q=85",
      "https://images.unsplash.com/photo-1566174053879-31528523f8ae?w=1000&q=85",
    ],
    handmadeHours: 35,
  },
  {
    id: "7",
    name: "ست عقد «پرند»",
    category: "aghd",
    description: "ست لباس و شنل با لبه‌دوزی ظریف؛ تمام ظرافت‌ها با دوخت دست.",
    fabric: "دانتل فرانسوی با آستر",
    colors: ["کرم", "طلایی"],
    sizes: ["۳۶", "۳۸", "۴۰", "۴۲"],
    price: 19200000,
    showPrice: true,
    images: [
      "https://images.unsplash.com/photo-1515886657613-9f3515b0c78f?w=1000&q=85",
      "https://images.unsplash.com/photo-1558171813-4c088753af8f?w=1000&q=85",
    ],
    featured: true,
    badge: "جدید",
    handmadeHours: 70,
  },
  {
    id: "8",
    name: "گان «ستاره شرقی»",
    category: "mjlsi",
    description: "دامن لایه‌لایهٔ ارگانزا با نقش‌ونگار شرقی؛ انتخابی که در ذهن می‌ماند.",
    fabric: "ارگانزا با سوزن‌دوزی دست",
    colors: ["بژ", "طلایی"],
    sizes: ["۳۶", "۳۸", "۴۰", "۴۲", "۴۴"],
    price: 27900000,
    showPrice: true,
    images: [
      "https://images.unsplash.com/photo-1496747611176-843222e1e57c?w=1000&q=85",
      "https://images.unsplash.com/photo-1595777457583-95e059d581b8?w=1000&q=85",
    ],
    badge: "سوزن‌دوزی",
    handmadeHours: 150,
  },
  {
    id: "9",
    name: "عروس «ونیز»",
    category: "aroos",
    description: "بالاتنهٔ ایلوژن با دانتل سرتاسری و مرواریددوزی ظریف.",
    fabric: "دانتل شانتیلی با مروارید طبیعی",
    colors: ["سفید"],
    sizes: ["۳۶", "۳۸", "۴۰", "۴۲", "۴۴", "۴۶"],
    price: 54000000,
    showPrice: true,
    images: [
      "https://images.unsplash.com/photo-1515372039744-b8f02a3ae446?w=1000&q=85",
      "https://images.unsplash.com/photo-1469334031218-e382a71b716b?w=1000&q=85",
    ],
    handmadeHours: 160,
  },
  {
    id: "10",
    name: "مجلسی «مروارید سیاه»",
    category: "mjlsi",
    description: "دامن پف‌دار و تافت براق؛ مشکیِ هیچ‌وقت قدیمی‌نشده.",
    fabric: "تافت ابریشم",
    colors: ["مشکی"],
    sizes: ["۳۶", "۳۸", "۴۰", "۴۲", "۴۴", "۴۶"],
    price: 17800000,
    showPrice: true,
    images: [
      "https://images.unsplash.com/photo-1566174053879-31528523f8ae?w=1000&q=85",
      "https://images.unsplash.com/photo-1558769132-cb1aea458c5e?w=1000&q=85",
    ],
    handmadeHours: 45,
  },
  {
    id: "11",
    name: "عقد «خورشید»",
    category: "aghd",
    description: "دامن کلوش و کمربند کارشده؛ طلایی‌ای که مثل خورشید می‌درخشد.",
    fabric: "شانل ابریشم",
    colors: ["طلایی", "کرم"],
    sizes: ["۳۶", "۳۸", "۴۰", "۴۲", "۴۴"],
    price: 23600000,
    showPrice: true,
    images: [
      "https://images.unsplash.com/photo-1558171813-4c088753af8f?w=1000&q=85",
      "https://images.unsplash.com/photo-1515886657613-9f3515b0c78f?w=1000&q=85",
    ],
    badge: "محبوب",
    featured: true,
    handmadeHours: 65,
  },
  {
    id: "12",
    name: "دوخت سفارشی «شما»",
    category: "custom",
    description: "بر اساس ایده، اندازه و سلیقهٔ شما طراحی و دوخته می‌شود.",
    longDescription:
      "از اسکچ اولیه تا فیتینگ نهایی کنار شماییم. پارچه، رنگ، سیلوئت و جزئیات کاملاً اختصاصی است.",
    fabric: "به انتخاب شما",
    colors: [],
    sizes: [],
    price: null,
    showPrice: false,
    images: [
      "https://images.unsplash.com/photo-1558769132-cb1aea458c5e?w=1000&q=85",
    ],
    badge: "اختصاصی",
  },
];

export const testimonials = [
  {
    id: "t1",
    name: "آوا کیانی",
    role: "عروس — لوتوس کلاسیک",
    text: "از اولین جلسه‌ای که وارد آتلیه شدم، می‌دانستم لباسم در دست درستی است. ظرافت دست‌دوز همه را شگفت‌زده کرد.",
  },
  {
    id: "t2",
    name: "سارا محمدی",
    role: "گان شب مهتاب",
    text: "برای اولین بار لباسی پوشیدم که دقیقاً برای تن من دوخته شده بود. کیفیت پارچه در حد برندهای اروپایی.",
  },
  {
    id: "t3",
    name: "مریم رضایی",
    role: "دوخت سفارشی عقد",
    text: "لباس را از روی یک عکس در ذهنم دوختند؛ نتیجه از تصور من بهتر شد.",
  },
  {
    id: "t4",
    name: "نیلوفر احمدی",
    role: "فیتینگ اختصاصی",
    text: "حوصله و دقت در جلسه‌های پرو بی‌نظیر بود. هر جزئیات با وسواس تمام شد.",
  },
];

export const galleryItems = [
  { id: "g1", src: "https://images.unsplash.com/photo-1595777457583-95e059d581b8?w=800&q=80", alt: "کالکشن مجلسی", type: "image" as const },
  { id: "g2", src: "https://images.unsplash.com/photo-1515372039744-b8f02a3ae446?w=800&q=80", alt: "لباس عروس", type: "image" as const },
  { id: "g3", src: "https://images.unsplash.com/photo-1558171813-4c088753af8f?w=800&q=80", alt: "جزئیات دوخت", type: "image" as const },
  { id: "g4", src: "https://images.unsplash.com/photo-1469334031218-e382a71b716b?w=800&q=80", alt: "فیتینگ", type: "image" as const },
  { id: "g5", src: "https://images.unsplash.com/photo-1566174053879-31528523f8ae?w=800&q=80", alt: "مجلسی شب", type: "image" as const },
  { id: "g6", src: "https://images.unsplash.com/photo-1558769132-cb1aea458c5e?w=800&q=80", alt: "آتلیه", type: "image" as const },
  { id: "g7", src: "https://images.unsplash.com/photo-1515886657613-9f3515b0c78f?w=800&q=80", alt: "کمپین", type: "image" as const },
  { id: "g8", src: "https://images.unsplash.com/photo-1496747611176-843222e1e57c?w=800&q=80", alt: "سوزن‌دوزی", type: "image" as const },
  { id: "g9", src: "https://images.unsplash.com/photo-1515372039744-b8f02a3ae446?w=800&q=80", alt: "جزئیات دانتل", type: "image" as const },
];
