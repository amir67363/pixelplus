import { useMemo, useState } from "react";
import { useSearchParams } from "react-router-dom";
import { motion } from "framer-motion";
import { categoryLabels, type Category } from "../data/products";
import ProductCard from "../components/ProductCard";
import { useProducts } from "../hooks/useProducts";
import { useSiteSettings } from "../hooks/useSiteSettings";
import PageTransition from "../components/PageTransition";
import { EASE, RM } from "../lib/motion";

const allCats: (Category | "all")[] = ["all", "mjlsi", "aroos", "aghd", "custom", "new"];

export default function Collections() {
  const [params, setParams] = useSearchParams();
  const cat = (params.get("cat") as Category | "all") || "all";
  const { products } = useProducts();
  const { settings } = useSiteSettings();
  const [q, setQ] = useState("");
  const [sort, setSort] = useState<"default" | "price-asc" | "price-desc">("default");

  const filtered = useMemo(() => {
    let list = products.map((p) =>
      settings.showPrices ? p : { ...p, showPrice: false }
    );
    if (cat !== "all") list = list.filter((p) => p.category === cat);
    if (q.trim()) {
      const s = q.trim();
      list = list.filter(
        (p) => p.name.includes(s) || p.description.includes(s) || p.fabric.includes(s)
      );
    }
    if (sort === "price-asc") {
      list = [...list].sort((a, b) => (a.price || 0) - (b.price || 0));
    } else if (sort === "price-desc") {
      list = [...list].sort((a, b) => (b.price || 0) - (a.price || 0));
    }
    return list;
  }, [cat, products, settings.showPrices, q, sort]);

  const setCat = (c: Category | "all") => {
    if (c === "all") setParams({});
    else setParams({ cat: c });
  };

  return (
    <PageTransition>
      <div className="pt-28 pb-20 min-h-screen">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-10">
            <div className="flex items-center justify-center gap-4 mb-4">
              <span className="h-px w-10 bg-gold-500/60" />
              <span className="font-latin tracking-[.4em] text-[11px] text-gold-500 uppercase">
                Collections
              </span>
              <span className="h-px w-10 bg-gold-500/60" />
            </div>
            <h1 className="section-title">کالکشن‌ها</h1>
          </div>

          <div className="flex flex-col md:flex-row gap-4 mb-8 items-stretch md:items-center justify-between">
            <div className="flex flex-wrap justify-center md:justify-start gap-2">
              {allCats.map((c) => (
                <button
                  key={c}
                  onClick={() => setCat(c)}
                  className={`px-4 py-2 text-xs tracking-wide transition-all duration-300 border ${
                    cat === c
                      ? "border-gold-500 bg-gold-500 text-noir-950 font-semibold"
                      : "border-ivory/15 text-ivory/55 hover:border-gold-500/40 hover:text-ivory"
                  }`}
                >
                  {c === "all" ? "همه" : categoryLabels[c]}
                </button>
              ))}
            </div>
            <div className="flex gap-2">
              <input
                value={q}
                onChange={(e) => setQ(e.target.value)}
                placeholder="جستجو در کالکشن..."
                className="input-luxury text-sm flex-1 md:w-52"
              />
              <select
                value={sort}
                onChange={(e) => setSort(e.target.value as typeof sort)}
                className="input-luxury text-xs w-36"
              >
                <option value="default">مرتب‌سازی</option>
                <option value="price-asc">ارزان‌تر</option>
                <option value="price-desc">گران‌تر</option>
              </select>
            </div>
          </div>

          <p className="text-ivory/30 text-xs mb-6">{filtered.length} محصول</p>

          <motion.div
            layout
            className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-5 md:gap-6"
          >
            {filtered.map((p, i) => (
              <ProductCard key={p.id} product={p} index={i} />
            ))}
          </motion.div>

          {filtered.length === 0 && (
            <p className="text-center text-ivory/35 py-20">موردی یافت نشد.</p>
          )}
        </div>
      </div>
    </PageTransition>
  );
}
