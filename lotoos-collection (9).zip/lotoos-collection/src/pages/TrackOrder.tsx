import { useMemo, useState, type FormEvent } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Search, Package, Clock, CheckCircle2, XCircle, Loader2, MessageSquare } from "lucide-react";
import { findOrderByTracking, type CustomOrder, type OrderStatus } from "../admin/store";
import { useSearchParams, Link } from "react-router-dom";

const steps: { key: OrderStatus; label: string }[] = [
  { key: "new", label: "ثبت درخواست" },
  { key: "reviewing", label: "بررسی و قیمت" },
  { key: "in_progress", label: "در حال دوخت" },
  { key: "done", label: "آماده تحویل" },
];

const statusMeta: Record<
  OrderStatus,
  { label: string; color: string; icon: typeof Package }
> = {
  new: { label: "درخواست ثبت شد", color: "text-champagne", icon: Package },
  reviewing: { label: "در حال بررسی و اعلام قیمت", color: "text-blue-300", icon: Clock },
  in_progress: { label: "در حال دوخت", color: "text-amber-300", icon: Loader2 },
  done: { label: "آماده / تحویل‌شده", color: "text-emerald-300", icon: CheckCircle2 },
  cancelled: { label: "لغو شده", color: "text-red-300", icon: XCircle },
};

function stepIndex(status: OrderStatus): number {
  if (status === "cancelled") return -1;
  return steps.findIndex((s) => s.key === status);
}

export default function TrackOrder() {
  const [params, setParams] = useSearchParams();
  const initial = params.get("code") || "";
  const [code, setCode] = useState(initial);
  const [query, setQuery] = useState(initial.toUpperCase());
  const [searched, setSearched] = useState(Boolean(initial));

  const order = useMemo(() => {
    if (!query) return null;
    return findOrderByTracking(query);
  }, [query]);

  const onSubmit = (e: FormEvent) => {
    e.preventDefault();
    const c = code.trim().toUpperCase();
    setQuery(c);
    setSearched(true);
    if (c) setParams({ code: c });
    else setParams({});
  };

  const formatPrice = (p: number) =>
    new Intl.NumberFormat("fa-IR").format(p) + " تومان";

  return (
    <div className="pt-28 pb-20 min-h-screen">
      <div className="max-w-xl mx-auto px-4 sm:px-6">
        <div className="text-center mb-12">
          <p className="section-subtitle">Order Tracking</p>
          <h1 className="section-title">پیگیری سفارش</h1>
          <p className="text-cream/45 text-sm mt-4 font-light leading-relaxed">
            کد پیگیری را که پس از ثبت درخواست دریافت کردید وارد کنید.
          </p>
        </div>

        <form onSubmit={onSubmit} className="flex gap-2 mb-10">
          <div className="relative flex-1">
            <Search size={16} className="absolute right-4 top-1/2 -translate-y-1/2 text-cream/30" />
            <input
              value={code}
              onChange={(e) => setCode(e.target.value.toUpperCase())}
              placeholder="مثلاً LT-SA7K2M"
              className="input-luxury pr-11 tracking-widest"
              dir="ltr"
              autoComplete="off"
            />
          </div>
          <button type="submit" className="btn-primary px-6 shrink-0">
            پیگیری
          </button>
        </form>

        <AnimatePresence mode="wait">
          {searched && !order && (
            <motion.div
              key="empty"
              initial={{ opacity: 0, y: 12 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0 }}
              className="text-center py-14 card-luxury"
            >
              <Package className="mx-auto text-cream/25 mb-4" size={36} strokeWidth={1.25} />
              <p className="text-cream/70 text-sm mb-2">سفارشی با این کد پیدا نشد</p>
              <p className="text-cream/35 text-xs">
                کد را دوباره بررسی کنید یا با ما{" "}
                <Link to="/contact" className="text-champagne hover:underline">
                  تماس بگیرید
                </Link>
                .
              </p>
            </motion.div>
          )}

          {order && (
            <motion.div
              key={order.id}
              initial={{ opacity: 0, y: 16 }}
              animate={{ opacity: 1, y: 0 }}
              className="space-y-5"
            >
              {/* Status header */}
              <div className="card-luxury p-6">
                <div className="flex items-start justify-between gap-4 mb-5">
                  <div>
                    <p className="text-[11px] text-cream/35 tracking-wider mb-1">کد پیگیری</p>
                    <p className="text-champagne text-lg tracking-[0.2em] font-medium" dir="ltr">
                      {order.trackingCode}
                    </p>
                  </div>
                  <StatusBadge status={order.status} />
                </div>

                {/* Timeline */}
                {order.status !== "cancelled" && (
                  <div className="flex items-center justify-between gap-1 mb-2 px-1">
                    {steps.map((s, i) => {
                      const active = stepIndex(order.status);
                      const done = i <= active;
                      return (
                        <div key={s.key} className="flex-1 flex flex-col items-center gap-2">
                          <div className="w-full flex items-center">
                            {i > 0 && (
                              <div
                                className={`h-px flex-1 ${done ? "bg-champagne/60" : "bg-white/10"}`}
                              />
                            )}
                            <div
                              className={`w-3 h-3 rounded-full shrink-0 ${
                                done ? "bg-champagne" : "bg-white/15"
                              }`}
                            />
                            {i < steps.length - 1 && (
                              <div
                                className={`h-px flex-1 ${i < active ? "bg-champagne/60" : "bg-white/10"}`}
                              />
                            )}
                          </div>
                          <span
                            className={`text-[9px] text-center leading-tight ${
                              done ? "text-champagne/90" : "text-cream/30"
                            }`}
                          >
                            {s.label}
                          </span>
                        </div>
                      );
                    })}
                  </div>
                )}
              </div>

              {/* Price */}
              <div className="card-luxury p-6">
                <p className="text-[11px] text-cream/35 tracking-wider mb-2">قیمت اعلام‌شده</p>
                {order.quotedPrice != null ? (
                  <p className="text-2xl font-light text-champagne">
                    {formatPrice(order.quotedPrice)}
                  </p>
                ) : (
                  <p className="text-cream/50 text-sm">
                    هنوز قیمتی اعلام نشده — پس از بررسی با شما هماهنگ می‌شود.
                  </p>
                )}
                {order.estimatedReady && (
                  <p className="text-cream/45 text-xs mt-3 flex items-center gap-2">
                    <Clock size={13} className="text-champagne/70" />
                    زمان تقریبی آماده‌سازی: {order.estimatedReady}
                  </p>
                )}
              </div>

              {/* Admin note */}
              {order.adminNote && (
                <div className="card-luxury p-6 border-champagne/15">
                  <p className="text-[11px] text-champagne/70 tracking-wider mb-3 flex items-center gap-2">
                    <MessageSquare size={13} />
                    پیام از آتللیه لوتوس
                  </p>
                  <p className="text-cream/80 text-sm leading-relaxed font-light whitespace-pre-wrap">
                    {order.adminNote}
                  </p>
                </div>
              )}

              {/* Order details */}
              <div className="card-luxury p-6 space-y-3 text-sm">
                <p className="text-[11px] text-cream/35 tracking-wider mb-1">جزئیات درخواست</p>
                <Row label="نام" value={order.name} />
                <Row label="نوع لباس" value={order.type} />
                <Row label="سایز" value={order.size || "—"} />
                <Row label="رنگ" value={order.color || "—"} />
                {order.notes && (
                  <div className="pt-2 border-t border-white/5">
                    <p className="text-cream/35 text-xs mb-1">توضیحات شما</p>
                    <p className="text-cream/70 text-sm leading-relaxed font-light">{order.notes}</p>
                  </div>
                )}
                <p className="text-[10px] text-cream/25 pt-2" dir="ltr">
                  ثبت: {new Date(order.createdAt).toLocaleString("fa-IR")}
                  {order.updatedAt &&
                    ` · به‌روزرسانی: ${new Date(order.updatedAt).toLocaleString("fa-IR")}`}
                </p>
              </div>

              <p className="text-center text-xs text-cream/30">
                سوالی دارید؟{" "}
                <Link to="/contact" className="text-champagne/80 hover:text-champagne">
                  تماس با ما
                </Link>
              </p>
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </div>
  );
}

function StatusBadge({ status }: { status: OrderStatus }) {
  const m = statusMeta[status];
  const Icon = m.icon;
  return (
    <span
      className={`inline-flex items-center gap-1.5 text-xs px-3 py-1.5 rounded-full bg-white/5 border border-white/10 ${m.color}`}
    >
      <Icon size={13} />
      {m.label}
    </span>
  );
}

function Row({ label, value }: { label: string; value: string }) {
  return (
    <div className="flex gap-3">
      <span className="text-cream/35 w-20 shrink-0 text-xs">{label}</span>
      <span className="text-cream">{value}</span>
    </div>
  );
}
