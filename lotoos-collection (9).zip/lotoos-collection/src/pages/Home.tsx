import Hero from "../components/Hero";
import Marquee from "../components/Marquee";
import CollectionSection from "../components/CollectionSection";
import GalleryPreview from "../components/GalleryPreview";
import AboutPreview from "../components/AboutPreview";
import Testimonials from "../components/Testimonials";
import { Link } from "react-router-dom";
import { useSiteSettings } from "../hooks/useSiteSettings";
import Reveal from "../components/Reveal";
import { EASE, RM } from "../lib/motion";
import { motion } from "framer-motion";

export default function Home() {
  const { settings } = useSiteSettings();
  const wa = settings.whatsapp.replace(/\D/g, "");

  return (
    <>
      <Hero />
      <Marquee
        items={[
          "لباس مجلسی",
          "لباس عروس",
          "لباس عقد",
          "دوخت سفارشی",
          "سوزن‌دوزی دست",
          "پارچه‌های ممتاز",
        ]}
      />
      <CollectionSection />
      <Marquee
        latin
        reverse
        items={[
          "Lotoos Collection",
          "Couture",
          "Bridal",
          "Evening",
          "Bespoke",
          "Atelier",
        ]}
      />
      <GalleryPreview />
      <AboutPreview />
      <Testimonials />

      <section className="py-28 md:py-36 relative overflow-hidden bg-noir-900 border-y border-gold-500/10">
        <div className="absolute inset-0 opacity-[0.12]">
          <img src={settings.heroImage} alt="" className="w-full h-full object-cover" />
        </div>
        <div className="absolute inset-0 bg-gradient-to-t from-noir-950 via-noir-950/85 to-noir-950/70" />
        <div className="relative max-w-2xl mx-auto text-center px-5">
          <Reveal y={28}>
            <div className="flex items-center justify-center gap-4 mb-5">
              <span className="h-px w-10 bg-gold-500/60" />
              <span className="font-latin tracking-[.4em] text-[11px] text-gold-500 uppercase">
                Begin Your Story
              </span>
              <span className="h-px w-10 bg-gold-500/60" />
            </div>
            <h2 className="section-title mb-5">{settings.ctaTitle}</h2>
            <p className="text-ivory/50 text-sm mb-10 max-w-md mx-auto leading-8 font-light">
              {settings.ctaText}
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Link to="/custom-order" className="btn-primary">
                ثبت درخواست طراحی
              </Link>
              <a
                href={`https://wa.me/${wa}`}
                target="_blank"
                rel="noreferrer"
                className="btn-outline"
              >
                گفتگو در واتساپ
              </a>
            </div>
          </Reveal>
        </div>
      </section>
    </>
  );
}
