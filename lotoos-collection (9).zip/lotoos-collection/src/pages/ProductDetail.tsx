import { useParams, Link } from "react-router-dom";
import { motion } from "framer-motion";
import { useState } from "react";
import { Heart, Clock, Sparkles } from "lucide-react";
import { categoryLabels } from "../data/products";
import { useProducts } from "../hooks/useProducts";
import { useSiteSettings } from "../hooks/useSiteSettings";
import { useFavorites } from "../hooks/useFavorites";
import { useToast } from "../components/Toast";
import PageTransition from "../components/PageTransition";
import ProductCard from "../components/ProductCard";
import { EASE, RM } from "../lib/motion";

export default function ProductDetail() {
  const { id } = useParams();
  const { products } = useProducts();
  const { settings } = useSiteSettings();
  const product = products.find((p) => p.id === id);
  const [activeImg, setActiveImg] = useState(0);
  const { has, toggle } = useFavorites();
  const toast = useToast();

  if (!product) {
    return (
      <div className="pt-32 pb-20 text-center">
        <p className="text-ivory/50 mb-6">محصول یافت نشد.</p>
        <Link to="/collections" className="btn-outline">
          بازگشت به کالکشن
        </Link>
      </div>
    );
  }

  const liked = has(product.id);
  const showPrice = settings.showPrices && product.showPrice && product.price;
  const formatPrice = (p: number) => new Intl.NumberFormat("fa-IR").format(p) + " تومان";
  const wa = settings.whatsapp.replace(/\D/g, "");
  const related = products
    .filter((p) => p.category === product.category && p.id !== product.id)
    .slice(0, 4);

  return (
    <PageTransition>
      <div className="pt-28 pb-20 min-h-screen">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 lg:gap-16">
            <div>
              <motion.div
                key={activeImg}
                initial={RM ? false : { opacity: 0 }}
                animate={{ opacity: 1 }}
                className="aspect-[3/4] overflow-hidden mb-4 bg-noir-900"
              >
                <img
                  src={product.images[activeImg] || product.images[0]}
                  alt={product.name}
                  className="w-full h-full object-cover"
                />
              </motion.div>
              <div className="flex gap-3">
                {product.images.filter(Boolean).map((img, i) => (
                  <button
                    key={i}
                    onClick={() => setActiveImg(i)}
                    className={`w-20 h-24 overflow-hidden border transition-colors ${
                      activeImg === i ? "border-gold-500" : "border-ivory/10"
                    }`}
                  >
                    <img src={img} alt="" className="w-full h-full object-cover" />
                  </button>
                ))}
              </div>
            </div>

            <div className="lg:pt-4">
              <p className="font-latin text-gold-500 text-[11px] tracking-[0.35em] uppercase mb-3">
                {categoryLabels[product.category]}
                {product.badge ? ` · ${product.badge}` : ""}
              </p>
              <h1 className="font-display text-4xl md:text-5xl text-ivory mb-5 leading-tight">
                {product.name}
              </h1>
              <p className="text-ivory/65 text-sm leading-8 mb-4 font-light">
                {product.description}
              </p>
              {product.longDescription && (
                <p className="text-ivory/45 text-sm leading-8 mb-8 font-light">
                  {product.longDescription}
                </p>
              )}

              <div className="space-y-4 mb-8 text-sm border-y border-ivory/8 py-6">
                <div className="flex gap-4">
                  <span className="text-ivory/35 w-28 shrink-0">جنس پارچه</span>
                  <span className="text-ivory">{product.fabric}</span>
                </div>
                {product.colors.length > 0 && (
                  <div className="flex gap-4">
                    <span className="text-ivory/35 w-28 shrink-0">رنگ‌بندی</span>
                    <span className="text-ivory">{product.colors.join(" · ")}</span>
                  </div>
                )}
                {product.sizes.length > 0 && (
                  <div className="flex gap-4">
                    <span className="text-ivory/35 w-28 shrink-0">سایزبندی</span>
                    <span className="text-ivory">{product.sizes.join(" · ")}</span>
                  </div>
                )}
                {product.handmadeHours && (
                  <div className="flex gap-4 items-center">
                    <span className="text-ivory/35 w-28 shrink-0">کار دست</span>
                    <span className="text-gold-400/90 flex items-center gap-2">
                      <Clock size={14} /> حدود {product.handmadeHours} ساعت
                    </span>
                  </div>
                )}
                {product.care && (
                  <div className="flex gap-4">
                    <span className="text-ivory/35 w-28 shrink-0">نگهداری</span>
                    <span className="text-ivory/70">{product.care}</span>
                  </div>
                )}
                {showPrice && (
                  <div className="flex gap-4 pt-2">
                    <span className="text-ivory/35 w-28 shrink-0">قیمت</span>
                    <span className="text-gold-400 text-xl font-medium">
                      {formatPrice(product.price!)}
                    </span>
                  </div>
                )}
              </div>

              <div className="flex flex-col sm:flex-row gap-3">
                <Link to="/custom-order" className="btn-primary flex-1 text-center">
                  سفارش این مدل
                </Link>
                <a
                  href={`https://wa.me/${wa}?text=${encodeURIComponent(
                    `سلام، درباره «${product.name}» می‌خواهم صحبت کنم.`
                  )}`}
                  target="_blank"
                  rel="noreferrer"
                  className="btn-outline flex-1 text-center"
                >
                  واتساپ
                </a>
                <button
                  type="button"
                  onClick={() => {
                    toggle(product.id);
                    toast(liked ? "از علاقه‌مندی‌ها حذف شد" : "به علاقه‌مندی‌ها اضافه شد");
                  }}
                  className={`btn-outline px-4 ${liked ? "border-gold-500 text-gold-400" : ""}`}
                >
                  <Heart size={16} fill={liked ? "currentColor" : "none"} />
                </button>
              </div>

              <div className="mt-8 flex items-start gap-3 text-xs text-ivory/40 leading-6">
                <Sparkles size={14} className="text-gold-500 shrink-0 mt-0.5" />
                امکان تغییر جزئیات، سایز و رنگ در سفارش اختصاصی وجود دارد. برای رزرو وقت مشاوره به
                بخش نوبت مراجعه کنید.
              </div>
            </div>
          </div>

          {related.length > 0 && (
            <div className="mt-24">
              <div className="flex items-center gap-4 mb-8">
                <span className="h-px w-10 bg-gold-500/60" />
                <h2 className="font-display text-2xl text-ivory">مشابه این مدل</h2>
              </div>
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-5">
                {related.map((p, i) => (
                  <ProductCard key={p.id} product={p} index={i} />
                ))}
              </div>
            </div>
          )}
        </div>
      </div>
    </PageTransition>
  );
}
