import { motion } from "framer-motion";
import { useSiteSettings } from "../hooks/useSiteSettings";

export default function About() {
  const { settings } = useSiteSettings();
  const paragraphs = settings.aboutText.split(/\n\n+/).filter(Boolean);

  return (
    <div className="pt-28 pb-20 min-h-screen">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <p className="section-subtitle">About</p>
          <h1 className="section-title">درباره {settings.brandName}</h1>
          <div className="w-12 h-px bg-champagne/40 mx-auto mt-6" />
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-14 lg:gap-20 items-center mb-24">
          <motion.div
            initial={{ opacity: 0, y: 28 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="aspect-[4/5] overflow-hidden rounded-2xl"
          >
            <img
              src={settings.aboutImage}
              alt={settings.aboutTitle}
              className="w-full h-full object-cover"
            />
          </motion.div>
          <motion.div
            initial={{ opacity: 0, y: 28 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ delay: 0.15 }}
            className="space-y-5 text-cream/65 text-sm leading-relaxed font-light"
          >
            <h2 className="text-2xl font-light text-cream mb-2 tracking-wide">
              {settings.aboutTitle}
            </h2>
            {paragraphs.map((p, i) => (
              <p key={i} className={i === paragraphs.length - 1 ? "text-champagne/85 font-normal" : ""}>
                {p}
              </p>
            ))}
          </motion.div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-5">
          {[
            { title: "طراحی", desc: "از اسکچ اولیه تا الگوی دقیق، هر طرح با توجه به آناتومی و سبک زندگی مشتری شکل می‌گیرد." },
            { title: "انتخاب پارچه", desc: "فقط پارچه‌های باکیفیت اروپایی و ایرانی اصیل. لمس و حرکت پارچه برای ما حیاتی است." },
            { title: "دوخت دستی", desc: "جزئیات نهایی، گلدوزی و اتصالات حساس با دست انجام می‌شود تا روح کار حفظ شود." },
          ].map((item, i) => (
            <motion.div
              key={item.title}
              initial={{ opacity: 0, y: 18 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: i * 0.1 }}
              className="card-luxury p-8 text-center"
            >
              <div className="w-10 h-px bg-champagne/50 mx-auto mb-6" />
              <h3 className="text-cream text-lg font-light mb-3 tracking-wide">{item.title}</h3>
              <p className="text-cream/45 text-sm leading-relaxed font-light">{item.desc}</p>
            </motion.div>
          ))}
        </div>
      </div>
    </div>
  );
}
