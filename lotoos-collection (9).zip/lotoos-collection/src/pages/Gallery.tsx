import { motion } from "framer-motion";
import { useState } from "react";
import { X } from "lucide-react";
import { useGallery } from "../hooks/useGallery";

export default function Gallery() {
  const { gallery } = useGallery();
  const [lightbox, setLightbox] = useState<string | null>(null);

  return (
    <div className="pt-28 pb-20 min-h-screen">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-14">
          <p className="section-subtitle">Gallery</p>
          <h1 className="section-title">گالری آثار</h1>
          <p className="text-cream/45 text-sm mt-4 max-w-md mx-auto font-light">
            نمونه‌کارها، جزئیات دوخت و لحظه‌های آتللیه
          </p>
        </div>

        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-3 md:gap-4">
          {gallery.map((item, i) => (
            <motion.button
              key={item.id}
              initial={{ opacity: 0, y: 18 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: i * 0.04, duration: 0.5 }}
              onClick={() => setLightbox(item.src)}
              className="relative aspect-square overflow-hidden rounded-xl group"
            >
              <img
                src={item.src}
                alt={item.alt}
                className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-110"
                loading="lazy"
              />
              <div className="absolute inset-0 bg-black/0 group-hover:bg-black/35 transition-colors duration-400" />
            </motion.button>
          ))}
        </div>

        {gallery.length === 0 && (
          <p className="text-center text-cream/30 py-20">هنوز تصویری در گالری نیست.</p>
        )}
      </div>

      {lightbox && (
        <div
          className="fixed inset-0 z-[100] bg-black/95 flex items-center justify-center p-4"
          onClick={() => setLightbox(null)}
        >
          <button
            className="absolute top-6 left-6 text-cream/70 hover:text-champagne"
            onClick={() => setLightbox(null)}
          >
            <X size={28} />
          </button>
          <img
            src={lightbox}
            alt=""
            className="max-h-[90vh] max-w-full object-contain rounded-lg"
            onClick={(e) => e.stopPropagation()}
          />
        </div>
      )}
    </div>
  );
}
