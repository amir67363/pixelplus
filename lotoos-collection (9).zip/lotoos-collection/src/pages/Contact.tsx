import { Instagram, Phone, MapPin, MessageCircle, ExternalLink } from "lucide-react";
import { motion } from "framer-motion";
import { useSiteSettings } from "../hooks/useSiteSettings";
import { buildMapEmbedUrl, buildMapLink } from "../admin/store";

export default function Contact() {
  const { settings } = useSiteSettings();
  const phoneDisplay = settings.phone.replace(/(\d{4})(\d{3})(\d{4})/, "$1 $2 $3");
  const phoneHref = settings.phone.startsWith("0")
    ? `+98${settings.phone.slice(1)}`
    : settings.phone;
  const wa = settings.whatsapp.replace(/\D/g, "");
  const mapEmbed = buildMapEmbedUrl(settings);
  const mapLink = buildMapLink(settings);

  const cards = [
    {
      icon: Phone,
      title: "تلفن",
      content: phoneDisplay,
      href: `tel:${phoneHref}`,
    },
    {
      icon: MessageCircle,
      title: "واتساپ",
      content: "شروع گفتگو",
      href: `https://wa.me/${wa}`,
    },
    {
      icon: Instagram,
      title: "اینستاگرام",
      content: `@${settings.instagram.replace("@", "")}`,
      href: `https://instagram.com/${settings.instagram.replace("@", "")}`,
    },
    {
      icon: MapPin,
      title: "آدرس فروشگاه / کارگاه",
      content: settings.address,
      href: mapLink,
    },
  ];

  return (
    <div className="pt-28 pb-20 min-h-screen">
      <div className="max-w-5xl mx-auto px-4 sm:px-6">
        <div className="text-center mb-14">
          <p className="section-subtitle">Contact</p>
          <h1 className="section-title">تماس و آدرس</h1>
          <div className="w-12 h-px bg-champagne/40 mx-auto mt-6" />
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 md:gap-5 mb-14">
          {cards.map((item, i) => (
            <motion.a
              key={item.title}
              href={item.href}
              target={item.href.startsWith("http") ? "_blank" : undefined}
              rel="noreferrer"
              initial={{ opacity: 0, y: 18 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: i * 0.08 }}
              className="card-luxury p-7 flex items-start gap-5 hover:border-champagne/35 transition-colors group"
            >
              <span className="w-11 h-11 rounded-full bg-champagne/10 border border-champagne/20 flex items-center justify-center shrink-0">
                <item.icon className="text-champagne" size={18} />
              </span>
              <div>
                <p className="text-cream/40 text-[11px] tracking-[0.2em] uppercase mb-1.5">
                  {item.title}
                </p>
                <p className="text-cream group-hover:text-champagne transition-colors text-sm leading-relaxed">
                  {item.content}
                </p>
              </div>
            </motion.a>
          ))}
        </div>

        {/* Map */}
        <motion.div
          initial={{ opacity: 0, y: 24 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="rounded-2xl overflow-hidden border border-white/8 bg-charcoal"
        >
          <div className="px-5 py-4 flex items-center justify-between border-b border-white/5">
            <div className="flex items-center gap-2">
              <MapPin size={16} className="text-champagne" />
              <span className="text-sm text-cream/80">موقعیت روی نقشه</span>
            </div>
            <a
              href={mapLink}
              target="_blank"
              rel="noreferrer"
              className="inline-flex items-center gap-1.5 text-xs text-champagne/80 hover:text-champagne transition-colors"
            >
              باز کردن در گوگل مپ
              <ExternalLink size={12} />
            </a>
          </div>
          <div className="relative w-full aspect-[16/9] md:aspect-[21/9] bg-black/40">
            <iframe
              title="نقشه فروشگاه لوتوس"
              src={mapEmbed}
              className="absolute inset-0 w-full h-full border-0 grayscale-[30%] contrast-[1.05]"
              loading="lazy"
              referrerPolicy="no-referrer-when-downgrade"
            />
          </div>
          <div className="px-5 py-3 text-xs text-cream/40 flex items-center gap-2">
            <MapPin size={12} />
            {settings.address}
          </div>
        </motion.div>

        <div className="text-center mt-12">
          <a
            href={`https://wa.me/${wa}`}
            target="_blank"
            rel="noreferrer"
            className="btn-primary inline-flex"
          >
            <MessageCircle size={17} />
            سفارش از طریق واتساپ
          </a>
        </div>
      </div>
    </div>
  );
}
