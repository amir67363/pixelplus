import { useState, type FormEvent } from "react";
import { motion } from "framer-motion";
import { Check, Calendar } from "lucide-react";
import PageTransition from "../components/PageTransition";
import { store } from "../admin/store";
import { EASE, RM } from "../lib/motion";

export default function Appointment() {
  const [done, setDone] = useState(false);

  const onSubmit = (e: FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const fd = new FormData(e.currentTarget);
    const msg = {
      id: crypto.randomUUID(),
      name: String(fd.get("name") || ""),
      contact: String(fd.get("phone") || ""),
      body: `رزرو مشاوره حضوری — تاریخ ترجیحی: ${fd.get("date")} — نوع: ${fd.get("type")} — ${fd.get("notes") || ""}`,
      read: false,
      createdAt: new Date().toISOString(),
    };
    store.setMessages([msg, ...store.getMessages()]);
    setDone(true);
  };

  if (done) {
    return (
      <PageTransition>
        <div className="pt-32 pb-20 min-h-screen flex items-center justify-center px-4">
          <motion.div
            initial={RM ? false : { opacity: 0, scale: 0.96 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.5, ease: EASE }}
            className="text-center max-w-md"
          >
            <div className="w-16 h-16 border border-gold-500/50 flex items-center justify-center mx-auto mb-6">
              <Check className="text-gold-500" size={28} />
            </div>
            <h1 className="font-display text-3xl text-ivory mb-3">درخواست رزرو ثبت شد</h1>
            <p className="text-ivory/55 text-sm leading-8 font-light">
              تیم لوتوس برای هماهنگی وقت مشاوره با شما تماس می‌گیرد.
            </p>
          </motion.div>
        </div>
      </PageTransition>
    );
  }

  return (
    <PageTransition>
      <div className="pt-28 pb-20 min-h-screen">
        <div className="max-w-xl mx-auto px-4 sm:px-6">
          <div className="text-center mb-12">
            <div className="flex items-center justify-center gap-3 mb-4">
              <span className="h-px w-10 bg-gold-500/60" />
              <span className="font-latin text-[11px] tracking-[0.4em] text-gold-500 uppercase">
                Atelier Visit
              </span>
              <span className="h-px w-10 bg-gold-500/60" />
            </div>
            <h1 className="section-title">رزرو مشاوره حضوری</h1>
            <p className="text-ivory/45 text-sm mt-4 leading-8 font-light">
              در فضای آتلیه، پارچه‌ها و نمونه‌کارها را از نزدیک ببینید و با طراح گفتگو کنید.
            </p>
          </div>

          <form onSubmit={onSubmit} className="space-y-5 border border-gold-500/15 bg-noir-900 p-6 md:p-8">
            <div className="grid sm:grid-cols-2 gap-5">
              <div>
                <label className="block text-xs text-ivory/45 mb-2">نام و نام خانوادگی</label>
                <input required name="name" className="input-luxury" placeholder="نام شما" />
              </div>
              <div>
                <label className="block text-xs text-ivory/45 mb-2">شماره تماس</label>
                <input required name="phone" type="tel" className="input-luxury" dir="ltr" placeholder="09..." />
              </div>
            </div>
            <div>
              <label className="block text-xs text-ivory/45 mb-2">نوع مشاوره</label>
              <select name="type" required className="input-luxury">
                <option value="">انتخاب کنید</option>
                <option value="لباس عروس">لباس عروس</option>
                <option value="لباس مجلسی">لباس مجلسی</option>
                <option value="لباس عقد">لباس عقد</option>
                <option value="طراحی اختصاصی">طراحی اختصاصی</option>
              </select>
            </div>
            <div>
              <label className="block text-xs text-ivory/45 mb-2">تاریخ ترجیحی</label>
              <input required name="date" type="date" className="input-luxury" dir="ltr" />
            </div>
            <div>
              <label className="block text-xs text-ivory/45 mb-2">توضیحات (اختیاری)</label>
              <textarea name="notes" rows={3} className="input-luxury resize-none" placeholder="ساعات مناسب، ایده اولیه..." />
            </div>
            <button type="submit" className="btn-primary w-full gap-2">
              <Calendar size={16} />
              ثبت درخواست رزرو
            </button>
          </form>
        </div>
      </div>
    </PageTransition>
  );
}
