import { useState, type FormEvent } from "react";
import { motion } from "framer-motion";
import { Upload, Check } from "lucide-react";
import { store, type CustomOrder, generateTrackingCode } from "../admin/store";
import { Link } from "react-router-dom";

export default function CustomOrderPage() {
  const [submitted, setSubmitted] = useState(false);
  const [trackingCode, setTrackingCode] = useState("");
  const [fileName, setFileName] = useState("");

  const handleSubmit = (e: FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const fd = new FormData(e.currentTarget);
    const code = generateTrackingCode();
    const order: CustomOrder = {
      id: crypto.randomUUID(),
      trackingCode: code,
      name: String(fd.get("name") || ""),
      phone: String(fd.get("phone") || ""),
      type: String(fd.get("type") || ""),
      size: String(fd.get("size") || ""),
      color: String(fd.get("color") || ""),
      notes: String(fd.get("notes") || ""),
      imageName: fileName || undefined,
      status: "new",
      createdAt: new Date().toISOString(),
      quotedPrice: null,
      adminNote: "",
      estimatedReady: "",
    };
    const existing = store.getOrders();
    store.setOrders([order, ...existing]);
    setTrackingCode(code);
    setSubmitted(true);
  };

  if (submitted) {
    return (
      <div className="pt-32 pb-20 min-h-screen flex items-center justify-center">
        <motion.div
          initial={{ opacity: 0, scale: 0.95 }}
          animate={{ opacity: 1, scale: 1 }}
          className="text-center max-w-md px-4"
        >
          <div className="w-16 h-16 rounded-full border border-champagne/50 flex items-center justify-center mx-auto mb-6">
            <Check className="text-champagne" size={28} />
          </div>
          <h2 className="text-2xl font-light text-cream mb-3">درخواست ثبت شد</h2>
          <p className="text-cream/60 text-sm leading-relaxed font-light mb-6">
            تیم لوتوس درخواست را بررسی می‌کند. کد پیگیری خود را نگه دارید:
          </p>
          <div className="rounded-2xl border border-champagne/30 bg-champagne/5 px-6 py-4 mb-6">
            <p className="text-[10px] text-cream/40 tracking-wider mb-1">کد پیگیری</p>
            <p className="text-champagne text-xl tracking-[0.25em] font-medium" dir="ltr">{trackingCode}</p>
          </div>
          <Link
            to={`/track?code=${trackingCode}`}
            className="btn-primary inline-flex text-xs"
          >
            پیگیری سفارش
          </Link>
        </motion.div>
      </div>
    );
  }

  return (
    <div className="pt-28 pb-20 min-h-screen">
      <div className="max-w-2xl mx-auto px-4 sm:px-6">
        <div className="text-center mb-12">
          <p className="section-subtitle">Custom Design</p>
          <h1 className="section-title">سفارش طراحی اختصاصی</h1>
          <p className="text-cream/45 text-sm mt-4 leading-relaxed font-light">
            ایده، سلیقه و جزئیات مورد نظرتان را بنویسید. ما از اینجا شروع می‌کنیم.
          </p>
        </div>

        <form onSubmit={handleSubmit} className="space-y-5">
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
            <div>
              <label className="block text-xs text-cream/45 mb-2 tracking-wide">نام و نام خانوادگی</label>
              <input required name="name" className="input-luxury" placeholder="نام شما" />
            </div>
            <div>
              <label className="block text-xs text-cream/45 mb-2 tracking-wide">شماره تماس</label>
              <input required name="phone" type="tel" className="input-luxury" placeholder="۰۹۱۲..." dir="ltr" />
            </div>
          </div>

          <div>
            <label className="block text-xs text-cream/45 mb-2 tracking-wide">نوع لباس مورد نظر</label>
            <select name="type" className="input-luxury" required>
              <option value="">انتخاب کنید</option>
              <option value="لباس مجلسی">لباس مجلسی</option>
              <option value="لباس عروس">لباس عروس</option>
              <option value="لباس عقد">لباس عقد</option>
              <option value="سایر">سایر</option>
            </select>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
            <div>
              <label className="block text-xs text-cream/45 mb-2 tracking-wide">سایز تقریبی</label>
              <input name="size" className="input-luxury" placeholder="مثلاً ۳۸" />
            </div>
            <div>
              <label className="block text-xs text-cream/45 mb-2 tracking-wide">رنگ پیشنهادی</label>
              <input name="color" className="input-luxury" placeholder="شامپاینی، مشکی، ..." />
            </div>
          </div>

          <div>
            <label className="block text-xs text-cream/45 mb-2 tracking-wide">توضیحات و ایده شما</label>
            <textarea
              name="notes"
              rows={5}
              className="input-luxury resize-none"
              placeholder="جزئیات مدل، الهام‌ها، محدودیت‌ها..."
            />
          </div>

          <div>
            <label className="block text-xs text-cream/45 mb-2 tracking-wide">آپلود عکس مدل (اختیاری)</label>
            <label className="flex items-center justify-center gap-3 border border-dashed border-white/12 hover:border-champagne/40 transition-colors rounded-2xl py-8 cursor-pointer">
              <Upload size={18} className="text-champagne/60" />
              <span className="text-sm text-cream/45">{fileName || "انتخاب تصویر"}</span>
              <input
                type="file"
                accept="image/*"
                className="hidden"
                onChange={(e) => setFileName(e.target.files?.[0]?.name || "")}
              />
            </label>
          </div>

          <button type="submit" className="btn-primary w-full py-4 text-sm tracking-widest">
            ثبت درخواست طراحی
          </button>
        </form>
      </div>
    </div>
  );
}
