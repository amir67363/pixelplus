import { Link } from "react-router-dom";
import { useFavorites } from "../hooks/useFavorites";
import { useProducts } from "../hooks/useProducts";
import ProductCard from "../components/ProductCard";
import PageTransition from "../components/PageTransition";
import { Heart } from "lucide-react";

export default function Favorites() {
  const { ids } = useFavorites();
  const { products } = useProducts();
  const list = products.filter((p) => ids.includes(p.id));

  return (
    <PageTransition>
      <div className="pt-28 pb-20 min-h-screen">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <div className="flex items-center justify-center gap-3 mb-4">
              <span className="h-px w-10 bg-gold-500/60" />
              <span className="font-latin text-[11px] tracking-[0.4em] text-gold-500 uppercase">
                Wishlist
              </span>
              <span className="h-px w-10 bg-gold-500/60" />
            </div>
            <h1 className="section-title">علاقه‌مندی‌ها</h1>
            <p className="text-ivory/40 text-sm mt-3">{list.length} مورد</p>
          </div>

          {list.length === 0 ? (
            <div className="text-center py-20 border border-gold-500/10 bg-noir-900">
              <Heart className="mx-auto text-ivory/20 mb-4" size={36} strokeWidth={1.25} />
              <p className="text-ivory/50 text-sm mb-6">هنوز چیزی ذخیره نکرده‌اید.</p>
              <Link to="/collections" className="btn-outline text-xs">
                مشاهده کالکشن
              </Link>
            </div>
          ) : (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-5">
              {list.map((p, i) => (
                <ProductCard key={p.id} product={p} index={i} />
              ))}
            </div>
          )}
        </div>
      </div>
    </PageTransition>
  );
}
