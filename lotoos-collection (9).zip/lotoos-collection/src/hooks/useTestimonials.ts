import { useEffect, useState, useCallback } from "react";
import { store, type TestimonialItem } from "../admin/store";

const EVENT = "lotoos-testimonials-changed";

export function useTestimonials() {
  const [items, setItems] = useState<TestimonialItem[]>(() => {
    if (typeof window === "undefined") return [];
    return store.getTestimonials();
  });

  useEffect(() => {
    const refresh = () => setItems(store.getTestimonials());
    refresh();
    window.addEventListener(EVENT, refresh);
    window.addEventListener("storage", refresh);
    return () => {
      window.removeEventListener(EVENT, refresh);
      window.removeEventListener("storage", refresh);
    };
  }, []);

  const update = useCallback((next: TestimonialItem[]) => {
    store.setTestimonials(next);
    setItems(next);
    window.dispatchEvent(new Event(EVENT));
  }, []);

  return { items, update };
}

export function notifyTestimonialsChanged() {
  if (typeof window !== "undefined") {
    window.dispatchEvent(new Event(EVENT));
  }
}
