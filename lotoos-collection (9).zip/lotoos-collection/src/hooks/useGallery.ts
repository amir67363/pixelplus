import { useEffect, useState, useCallback } from "react";
import { store, type GalleryItem } from "../admin/store";

const EVENT = "lotoos-gallery-changed";

export function useGallery() {
  const [gallery, setGallery] = useState<GalleryItem[]>(() => {
    if (typeof window === "undefined") return [];
    return store.getGallery();
  });

  useEffect(() => {
    const refresh = () => setGallery(store.getGallery());
    refresh();
    window.addEventListener(EVENT, refresh);
    window.addEventListener("storage", refresh);
    return () => {
      window.removeEventListener(EVENT, refresh);
      window.removeEventListener("storage", refresh);
    };
  }, []);

  const update = useCallback((next: GalleryItem[]) => {
    store.setGallery(next);
    setGallery(next);
    window.dispatchEvent(new Event(EVENT));
  }, []);

  return { gallery, update };
}

export function notifyGalleryChanged() {
  if (typeof window !== "undefined") {
    window.dispatchEvent(new Event(EVENT));
  }
}
