import { useEffect, useState, useCallback } from "react";
import { store, type SiteSettings, defaultSettings } from "../admin/store";

const EVENT = "lotoos-settings-changed";

export function useSiteSettings() {
  const [settings, setSettings] = useState<SiteSettings>(() => {
    if (typeof window === "undefined") return defaultSettings;
    return store.getSettings();
  });

  useEffect(() => {
    const refresh = () => setSettings(store.getSettings());
    refresh();
    window.addEventListener(EVENT, refresh);
    window.addEventListener("storage", refresh);
    return () => {
      window.removeEventListener(EVENT, refresh);
      window.removeEventListener("storage", refresh);
    };
  }, []);

  const update = useCallback((next: SiteSettings) => {
    store.setSettings(next);
    setSettings(next);
    window.dispatchEvent(new Event(EVENT));
  }, []);

  return { settings, update };
}

export function notifySettingsChanged() {
  if (typeof window !== "undefined") {
    window.dispatchEvent(new Event(EVENT));
  }
}
