import { useEffect, useState, useCallback } from "react";
import { store, type Product } from "../admin/store";

const EVENT = "lotoos-products-changed";

export function useProducts() {
  const [products, setProducts] = useState<Product[]>(() => {
    if (typeof window === "undefined") return [];
    return store.getProducts();
  });

  useEffect(() => {
    const refresh = () => setProducts(store.getProducts());
    refresh();
    window.addEventListener(EVENT, refresh);
    window.addEventListener("storage", refresh);
    return () => {
      window.removeEventListener(EVENT, refresh);
      window.removeEventListener("storage", refresh);
    };
  }, []);

  const update = useCallback((next: Product[]) => {
    store.setProducts(next);
    setProducts(next);
    window.dispatchEvent(new Event(EVENT));
  }, []);

  return { products, update };
}

export function notifyProductsChanged() {
  if (typeof window !== "undefined") {
    window.dispatchEvent(new Event(EVENT));
  }
}
